#include "optimizer.hh"

#include <llvm/Passes/PassBuilder.h>

llvm::PreservedAnalyses
sysu::StaticCallCounterPrinter::run(llvm::Module &M,
                                    llvm::ModuleAnalysisManager &MAM) {

  auto DirectCalls = MAM.getResult<sysu::StaticCallCounter>(M);

  OS << "=================================================\n";
  OS << "sysu-optimizer: static analysis results\n";
  OS << "=================================================\n";
  const char *str1 = "NAME", *str2 = "#N DIRECT CALLS";
  OS << llvm::format("%-20s %-10s\n", str1, str2);
  OS << "-------------------------------------------------\n";

  for (auto &CallCount : DirectCalls) {
    OS << llvm::format("%-20s %-10lu\n",
                       CallCount.first->getName().str().c_str(),
                       CallCount.second);
  }

  OS << "-------------------------------------------------\n\n";
  return llvm::PreservedAnalyses::all();
}

sysu::StaticCallCounter::Result
sysu::StaticCallCounter::run(llvm::Module &M, llvm::ModuleAnalysisManager &) {
  llvm::MapVector<const llvm::Function *, unsigned> Res;

  for (auto &Func : M) {
    for (auto &BB : Func) {
      for (auto &Ins : BB) {

        // If this is a call instruction then CB will be not null.
        auto *CB = llvm::dyn_cast<llvm::CallBase>(&Ins);
        if (nullptr == CB) {
          continue;
        }

        // If CB is a direct function call then DirectInvoc will be not null.
        auto DirectInvoc = CB->getCalledFunction();
        if (nullptr == DirectInvoc) {
          continue;
        }

        // We have a direct function call - update the count for the function
        // being called.
        auto CallCount = Res.find(DirectInvoc);
        if (Res.end() == CallCount) {
          CallCount = Res.insert({DirectInvoc, 0}).first;
        }
        ++CallCount->second;
      }
    }
  }

  return Res;
}

llvm::PreservedAnalyses
sysu::MyHello::run(llvm::Function &F,llvm::FunctionAnalysisManager &FAM){
  llvm::errs() << "Hello: ";
  llvm::errs() << F.getName() << '\n';
  return llvm::PreservedAnalyses::all();
}

llvm::PreservedAnalyses
sysu::DeadCodeElimination::run(llvm::Function &F,llvm::FunctionAnalysisManager &FAM){

  std::map<std::string,bool> localValuse;
  for(auto &block : F.getBasicBlockList()){
    for(auto &inst : block.getInstList()){
      if(inst.getOpcode() == llvm::Instruction::Alloca) {
        // llvm::errs()<<inst.getName().str()<<"\n";
        localValuse[inst.getName().str()] = false;
      }
      if(inst.getOpcode() == llvm::Instruction::Store) {
        continue;
      }
      for(auto &U : inst.operands()){
         if (llvm::Value *Use = U.get()){
            // llvm::errs()<<Use->getName().str()<<"\n";
            if(Use->getName().str() != ""){
              localValuse[Use->getName().str()] = true;
              // llvm::errs()<<Use->getName().str()<<" turn true"<<"\n";
            }
         }
      }
    }
  }

  for(auto &block : F.getBasicBlockList()){
      std::vector<llvm::Instruction*> toRemove;
      auto iter = block.getInstList().begin(); 
      while(iter != block.getInstList().end()){
        bool if_use = true;
        auto inst = &*iter; 
        iter++; 
        if(inst->getOpcode() == llvm::Instruction::Store) {
          for(auto &U : inst->operands()){
            if (llvm::Value *Use = U.get()){
              if(Use->getName().str() != "" && localValuse.find(Use->getName().str()) != localValuse.end()){
                if_use = localValuse[Use->getName().str()];
              }
            }
          }
        }
        else if(inst->getOpcode() == llvm::Instruction::Alloca) {
          if_use = localValuse[inst->getName().str()];
        }
        if(!if_use) toRemove.push_back(inst); 
      }
      for(auto &inst : toRemove) inst->removeFromParent();
  }
  return llvm::PreservedAnalyses::none();
}

bool sysu::DeadCodeElimination::isInstructionDead(llvm::Instruction &I){
  return false;
}


llvm::AnalysisKey sysu::StaticCallCounter::Key;

extern "C" {
llvm::PassPluginLibraryInfo LLVM_ATTRIBUTE_WEAK llvmGetPassPluginInfo() {
  return {LLVM_PLUGIN_API_VERSION, "sysu-optimizer-pass", LLVM_VERSION_STRING,
          [](llvm::PassBuilder &PB) {
            // #1 REGISTRATION FOR "opt -passes=sysu-optimizer-pass"
            PB.registerPipelineParsingCallback(
                [&](llvm::StringRef Name, llvm::ModulePassManager &MPM,
                    llvm::ArrayRef<llvm::PassBuilder::PipelineElement>) {
                  if (Name == "sysu-optimizer-pass") {
                    MPM.addPass(sysu::StaticCallCounterPrinter(llvm::errs()));
                    return true;
                  }
                  return false;
                });
            // #2 REGISTRATION FOR
            // "MAM.getResult<sysu::StaticCallCounter>(Module)"
            PB.registerAnalysisRegistrationCallback(
                [](llvm::ModuleAnalysisManager &MAM) {
                  MAM.registerPass([&] { return sysu::StaticCallCounter(); });
                });
          }};
}
}
