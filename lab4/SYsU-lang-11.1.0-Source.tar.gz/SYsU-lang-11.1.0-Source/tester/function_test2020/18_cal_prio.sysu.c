#include <sysy/sylib.h>
int a;
int b;
int c;
int main(){
	a = getint();
	b = getint();
	c = getint();
	int d;
	d = a+b*c;
	return d;
}
