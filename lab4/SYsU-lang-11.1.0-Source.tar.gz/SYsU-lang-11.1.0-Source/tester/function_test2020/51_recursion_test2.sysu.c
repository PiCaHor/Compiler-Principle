int fib(int n) {
	if (n == 0)
		return 0;
	if (n == 1)
		return 1;
	int p;
	p = n - 1;
	int q;
	q = n - 2;
	return fib(p) + fib(q);
}

int main() {
	int tmp;
	tmp = 10;
	return fib(tmp);
}