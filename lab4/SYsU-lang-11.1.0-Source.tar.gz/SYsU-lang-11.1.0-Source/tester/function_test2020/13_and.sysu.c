#include <sysy/sylib.h>
int a;
int b;
int main(){
	a = getint();
	b = getint();
	if ( a && b ) {
		return 1;
	}
	else {
		return 0;
	}
}
