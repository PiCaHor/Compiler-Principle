#include <sysy/sylib.h>
int N;

int newline;

int split(int n ,int a[])
{
    int i;
    i=N-1;
    while(i!=-1)
    {
        a[i]=n%10;
        n=n/10;
        i=i-1;

    }

    return 0;
}

int main()
{
    N=4;
    newline=10;
    int i;
    int m;
    int b[4];
    m = 1478;
    m = split(m,b);
    int t;
    i=0;
    while(i<4)
    {
        t=b[i];
        putint(t);
        putch(newline);
        i=i+1;

    }
    return 0;
}
