//test domain of global var define and local define
int a = 3;
int b = 5;

int main(){
    int a = 5;
    return a + b;
}