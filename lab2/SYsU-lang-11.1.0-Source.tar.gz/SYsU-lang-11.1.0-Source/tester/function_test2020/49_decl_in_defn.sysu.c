#include <sysy/sylib.h>
int main () {
    int a;
    a = 12;
    int t;
    putint(a);
    return 0;
}
