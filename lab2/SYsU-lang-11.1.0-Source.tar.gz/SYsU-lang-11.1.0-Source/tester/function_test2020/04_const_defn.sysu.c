const int x=4;

int main(){
    return x;
}