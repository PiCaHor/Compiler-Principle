int a;
int main(){
	a=10;
	return 0;
}
