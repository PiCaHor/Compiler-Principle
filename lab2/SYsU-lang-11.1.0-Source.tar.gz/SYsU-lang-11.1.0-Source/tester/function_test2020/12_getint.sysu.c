#include <sysy/sylib.h>
int main(){
	int a;
	a = getint();
	return a;
}
