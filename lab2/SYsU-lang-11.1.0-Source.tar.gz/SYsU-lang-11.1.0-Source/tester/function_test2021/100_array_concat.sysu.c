#include <sysy/sylib.h>

int concat(int a0[],int b0[],int c0[])
{
    int i;
    i=0;
    while(i<3)
    {
        c0[i]=a0[i];
      
        i=i+1;
    } 
    int j;
    j=0;
    while(j<3)
    {
        c0[i]=b0[j];
        i=i+1;
        j=j+1;
    }

    return 0;

}

int main()
{
    int a0[3];int a1[3]; int a2[3];int b0[3];int b1[3];int b2[3];int c0[6];int c1[3];int c2[3];
    int i;
    i=0;
    while(i<3)
    {
        a0[i]=i;
        a1[i]=i;
        a2[i]=i;
        b0[i]=i;
        b1[i]=i;
        b2[i]=i;
        i=i+1;
    }
    i=concat( a0,b0, c0);
    int x;
    while(i<6)
    {
        x = c0[i];
        putint(x);
        i=i+1;
    }
    x = 10;
    putch(x);

    return 0;
}
