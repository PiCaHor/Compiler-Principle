//test global var define
const int a = 10;

int main(){
    return a;
}