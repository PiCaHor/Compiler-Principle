int main() {
  int a = 10;
  ;
  return a * 2 + 1;
}
