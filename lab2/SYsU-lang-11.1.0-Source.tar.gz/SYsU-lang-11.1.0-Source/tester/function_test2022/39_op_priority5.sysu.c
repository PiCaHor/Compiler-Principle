#include <sysy/sylib.h>
int a = 1;
int b = 0;
int c = 1;
int d = 2;
int e = 4;
int main()
{
	int flag=0;
	if(a * b / c == e + d && a * (a + b) + c <= d + e || a - (b * c) == d - a / c)
	{
		flag=1;
	}
	putint(flag);
	return flag;
}