int a[10][10];
int main(){
    return 0;
}