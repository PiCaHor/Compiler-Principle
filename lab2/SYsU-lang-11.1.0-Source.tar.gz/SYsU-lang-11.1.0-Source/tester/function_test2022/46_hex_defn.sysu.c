// test hexadecimal define
int main(){
    int a;
    a = 0xf;
    return a;
}