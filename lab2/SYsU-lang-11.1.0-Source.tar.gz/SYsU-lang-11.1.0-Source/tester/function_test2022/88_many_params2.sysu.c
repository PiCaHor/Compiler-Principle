#include <sysy/sylib.h>

int func(int a, int b[][59], int c, int d[], int e, int f, int g[], int h, int i)
{
    int index = 0;
    while (index < 10) {
        putint(b[a][index]);
        index = index + 1;
    }
    putch(10);

    putint(d[c]);
    putch(10);

    while (i < 10) {
        g[i] = h * 128875 % 3724;
        i = i + 1;
        h = h + 7;
    }

    return e + f;
}

int main()
{
    int a[61][67] = {};
    int b[53][59] = {};

    a[17][1] = 6;
    a[17][3] = 7;
    a[17][4] = 4;
    a[17][7] = 9;
    a[17][11] = 11;

    b[6][1] = 1;
    b[6][2] = 2;
    b[6][3] = 3;
    b[6][9] = 9;

    int ret;
    ret = func(a[17][1], b, a[17][3], a[17], b[6][3], b[6][0], b[6], b[34][4], b[51][18]) * 3;

    while (ret >= 0) {
        putint(b[6][ret]); putch(32);
        ret = ret - 1;
    }
    putch(10);
    return 0;
}
