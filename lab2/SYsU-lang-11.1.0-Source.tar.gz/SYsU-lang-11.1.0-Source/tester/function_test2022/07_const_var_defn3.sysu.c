//test const local var define
int main(){
    const int a = 10, b = 5;
    return b;
}