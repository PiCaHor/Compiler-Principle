#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>
#include <llvm/Support/JSON.h>
#include <llvm/Support/MemoryBuffer.h>
#include <llvm/Support/raw_ostream.h>
#include <algorithm>
#include <iostream>

namespace {
llvm::LLVMContext TheContext;
llvm::Module TheModule("-", TheContext);
std::vector<std::string> gVarName; 

llvm::Type* getType(std::string type,bool check_array = true){
  llvm::Type* res; 

  int type_finish;
  std::string type_tmp = type;

  type_finish = type_tmp.find("[");
  type_tmp = type_tmp.substr(0,type_finish);
  type_finish = type_tmp.find("(");
  type_tmp = type_tmp.substr(0,type_finish);

  if(type_tmp.find("int") != std::string::npos){
    res = llvm::Type::getInt32Ty(TheContext);
  }
  else if(type_tmp.find("void") != std::string::npos){
    res = llvm::Type::getVoidTy(TheContext);
  }
  if(!check_array) return res;
  type_tmp = type;
  type_finish = type_tmp.find("[");
  if(type_finish != -1){
    int lpos = type_tmp.find("]",type_finish); 
    int num = stoi(type_tmp.substr(type_finish+1,lpos-type_finish-1));
    res = llvm::ArrayType::get(res, num);
  }
  type_tmp = type_tmp.substr(0,type_finish);
  type_finish = type.find("*");
  if(type_finish != -1){
    res = llvm::PointerType::get(res,0);
  }

  return res;
}

bool if_param;
llvm::Value* buildExp(const llvm::json::Object *O,
                      llvm::IRBuilder<> &Builder,std::map<std::string,
                      llvm::AllocaInst *> lVarName,
                      std::vector<llvm::BasicBlock*> *block_list = nullptr,
                      llvm::BasicBlock *enter = nullptr,
                      llvm::BasicBlock *leave = nullptr,
                      bool if_comming_init = false)
{
  auto kind = O->get("kind")->getAsString()->str();
  llvm::Value *LHS = nullptr; 
  llvm::Value *RHS = nullptr; 
  if(kind == "BinaryOperator"){
    auto binner = O->getArray("inner"); 
    auto opcode = O->get("opcode")->getAsString()->str(); 
    if(opcode == "&&"){
      for (const auto &it : *binner){
        llvm::BasicBlock* lhs_BB = llvm::BasicBlock::Create(TheContext,"land.lhs.true");
        llvm::BasicBlock* nowBB = Builder.GetInsertBlock();
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave); 
          if( !LHS->getType()->isIntegerTy(1)){
            LHS = Builder.CreateICmpNE(LHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
          }
          Builder.CreateCondBr(LHS, lhs_BB, leave);
          block_list->push_back(lhs_BB);
          Builder.SetInsertPoint(lhs_BB); 
        }
        else{
          RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave);
        }
      }
      return RHS;
    }
    
    if(opcode == "||"){
      for (const auto &it : *binner){
        llvm::BasicBlock* lhs_BB = llvm::BasicBlock::Create(TheContext,"lor.lhs.false");
        llvm::BasicBlock* nowBB = Builder.GetInsertBlock();
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,lhs_BB); 
          if( !LHS->getType()->isIntegerTy(1)){
            LHS = Builder.CreateICmpNE(LHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
          }
          Builder.CreateCondBr(LHS, enter, lhs_BB);
          block_list->push_back(lhs_BB);
          Builder.SetInsertPoint(lhs_BB); 
        }
        else{
          RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave);
        }
      }
      return RHS;
    }

    for (const auto &it : *binner){
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list);
        }

        else {
          RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list);
        }
    }
    
    if(opcode == "+"){
      return Builder.CreateAdd(LHS, RHS,"add");
    }

    else if(opcode == "-"){
      return Builder.CreateSub(LHS, RHS,"sub");
    }

    else if(opcode == "*"){
      return Builder.CreateMul(LHS, RHS,"mul");
    }

    else if(opcode == "/"){
      return Builder.CreateSDiv(LHS, RHS,"div");
    }

    else if(opcode == "%"){
      return Builder.CreateSRem(LHS, RHS,"rem");
    }

    else if(opcode == "="){
      return Builder.CreateStore(RHS, LHS);
    }

    else if(opcode == ">"){
      return Builder.CreateICmpSGT(LHS, RHS,"cmp");
    }

    else if(opcode == "<"){
      return Builder.CreateICmpSLT(LHS, RHS,"cmp");
    }

    else if(opcode == "=="){
      return Builder.CreateICmpEQ(LHS, RHS,"cmp");
    }
    
    else if(opcode == "!="){
      return Builder.CreateICmpNE(LHS, RHS,"cmp");
    }

    else if(opcode == "<="){
      return Builder.CreateICmpSLE(LHS, RHS,"cmp");
    }

    else if(opcode == ">="){
      return Builder.CreateICmpSGE(LHS, RHS,"cmp");
    }
  }

  else if(kind == "UnaryOperator"){
    auto uinner = O->getArray("inner"); 
    auto opcode = O->get("opcode")->getAsString()->str(); 

    for (const auto &it : *uinner){
      RHS = buildExp(it.getAsObject(),Builder,lVarName);
    }

    if(opcode == "-"){
      if(!RHS->getType()->isIntegerTy(32)){
        RHS = Builder.CreateZExt(RHS,llvm::Type::getInt32Ty(TheContext),RHS->getName().str()+".ext");
      }
      LHS = llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0));
      return Builder.CreateSub(LHS, RHS,"sub");
    }
    else if(opcode == "+"){
      // LHS = llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0));
      // return Builder.CreateAdd(LHS, RHS,"add");
      return RHS;
    }
    else if(opcode == "!"){
      if(!RHS->getType()->isIntegerTy(1)){
        RHS = Builder.CreateICmpNE(RHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
      }
      return Builder.CreateXor(RHS,llvm::ConstantInt::getTrue(TheContext),"lnot");
    }
  }

  else if(kind == "IntegerLiteral")
  {
    auto val = O->get("value")->getAsString()->str();
    return llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10));
  }

  else if(kind == "DeclRefExpr")
  {
    std::string declrefname = O->get("referencedDecl")->getAsObject()->get("name")->getAsString()->str();
    std::string declrefkind = O->get("referencedDecl")->getAsObject()->get("kind")->getAsString()->str();
    auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
    std::map<std::string,llvm::AllocaInst *>::iterator mit;
    mit=lVarName.find(declrefname);
    if(mit!=lVarName.end())
    {
      if(declrefkind == "ParmVarDecl" && getType(type)->getTypeID() != 11) if_param = 1;
      return lVarName[declrefname];
    }

    std::vector <std::string>::iterator it; 
    it = find(gVarName.begin(), gVarName.end(), declrefname);
    if(it != gVarName.end()){
      return TheModule.getNamedGlobal(declrefname); 
    }
  }

  else if(kind == "ImplicitCastExpr")
  {
    auto castinner = O->getArray("inner"); 
    auto castKind = O->get("castKind")->getAsString()->str();
    for (const auto &it : *castinner){
      if(castKind == "LValueToRValue"){
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        return Builder.CreateLoad(ptr);
      }
      return buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
    }
  }

  else if(kind == "ParenExpr")
  {
    auto pinner = O->getArray("inner"); 
    for (const auto &it : *pinner){
      return buildExp(it.getAsObject(),Builder,lVarName);
    }
  }

  else if(kind == "CallExpr")
  {
    auto callinner = O->getArray("inner"); 
    std::vector <llvm::Value*> actargs;
    std::string fun_name;
    for (const auto &it : *callinner){
        if(fun_name == "") {
          auto P = it.getAsObject()->get("inner")->getAsArray();
          for(const auto &iit : *P){
            fun_name = iit.getAsObject()->get("referencedDecl")->getAsObject()->get("name")->getAsString()->str();
          }
        }
        else{
          auto arg_tmp = buildExp(it.getAsObject(),Builder,lVarName); 
          llvm::Value* res = arg_tmp;
          if(arg_tmp->getType()->getTypeID() == 15){
            auto param_type = arg_tmp->getType()->getPointerElementType();
            if(param_type->getTypeID() != 11){
              res = Builder.CreateInBoundsGEP(param_type, arg_tmp,
                                                    {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)), 
                                                    llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0))});              
            }
          }
          actargs.push_back(res);
        }
    }
    
    llvm::Function *TheFunction = TheModule.getFunction(fun_name);
    auto fun_type = TheFunction->getReturnType();
    if(fun_type->isVoidTy()){
      return Builder.CreateCall(TheFunction->getFunctionType(),TheFunction, actargs);
    }
    return Builder.CreateCall(TheFunction, actargs,"call");
  }

  else if(kind == "ArraySubscriptExpr")
  {
    if_param = 0;
    auto binner = O->getArray("inner"); 
    bool if_param_tmp = 0;
    for (const auto &it : *binner){
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
          if_param_tmp = if_param;
          if_param = 0;
        }

        else {
          RHS = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        }
    }
    if(RHS->getType()->isIntegerTy(32)){
      RHS = Builder.CreateSExt(RHS,llvm::Type::getInt64Ty(TheContext),"idxprom");
    }
    if(LHS->getType()->getTypeID() == 15 && !if_comming_init && if_param_tmp){
      return Builder.CreateInBoundsGEP(LHS, RHS,"arrayidx");
    }
    else {
      return Builder.CreateInBoundsGEP(LHS, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)), RHS},"arrayidx");
    }
  }
  return nullptr;
}

llvm::Value * make_index(int cnt,std::vector<int> &arraynum,int dep)
{
  int tmp = cnt;
  for(int i=arraynum.size()-1;i>dep;--i){
    tmp /= arraynum[i];
  } 
  return llvm::ConstantInt::get(TheContext, llvm::APInt(32, tmp%arraynum[dep]));

}

void array_init(int dep,llvm::IRBuilder<> &Builder,std::vector<int> &arraynum,int &cnt,
                const llvm::json::Object *O,llvm::Value* arr,std::map<std::string,llvm::AllocaInst *> lVarName){
  auto kind = O->get("kind")->getAsString()->str(); 
  if(dep == arraynum.size()){
    llvm::Value* init_ptr = buildExp(O,Builder,lVarName,nullptr,nullptr,nullptr,true);
    Builder.CreateStore(init_ptr,arr);
    ++cnt;
    return ;
  }

  if(kind == "InitListExpr")
  {
    auto init_inner = O->get("inner")->getAsArray(); 
    for (const auto &it : *init_inner){
      auto gep_ptr = Builder.CreateInBoundsGEP(arr, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)),make_index(cnt,arraynum,dep)});
      array_init(dep+1,Builder,arraynum,cnt,it.getAsObject(),gep_ptr,lVarName);
    }
  }
}

std::vector<llvm::BasicBlock*> BuildCompound(const llvm::json::Object *O,
                                std::map<std::string,llvm::AllocaInst *> &lVarName,
                                llvm::BasicBlock *ret_BB,
                                llvm::BasicBlock *BB = nullptr,
                                std::string BB_name = "",
                                llvm::BasicBlock *leave = nullptr,
                                llvm::BasicBlock *while_leave = nullptr,
                                llvm::BasicBlock *while_enter = nullptr,
                                bool top_com = false){
  if(BB == nullptr) BB = llvm::BasicBlock::Create(TheContext, BB_name);
  std::vector<llvm::BasicBlock*> res_block;
  res_block.push_back(BB);

  bool block_write = 0;
  llvm::IRBuilder<> Builder(BB);
  auto inner = O->getArray("inner");
  for (const auto &it : *inner){
    block_write = 1;
    auto kind = it.getAsObject()->get("kind")->getAsString()->str();
    if (kind == "ReturnStmt"){
      auto rinner = it.getAsObject()->getArray("inner"); 
      if(rinner!=nullptr){
        for (const auto &ir : *rinner){
          auto ret_val = buildExp(ir.getAsObject(),Builder,lVarName);
          auto ret_ptr = lVarName["retval"];
          Builder.CreateStore(ret_val,ret_ptr);
        }
      }
      else lVarName["retval"] = nullptr;
      leave = ret_BB;
    }

    else if (kind == "BinaryOperator"){
      auto opcode = it.getAsObject()->get("opcode")->getAsString()->str(); 
      auto binner = it.getAsObject()->getArray("inner"); 


      if(opcode == "=")
      {
        buildExp(it.getAsObject(),Builder,lVarName);
      }
    }

    else if (kind == "CallExpr"){
      buildExp(it.getAsObject(),Builder,lVarName);
    }

    else if (kind == "IfStmt"){
      auto ifinner = it.getAsObject()->getArray("inner"); 
      auto ifhaselse = it.getAsObject()->get("hasElse");     
      llvm::Value* icmp_ptr;
      std::vector<llvm::BasicBlock*> True_BB;
      llvm::BasicBlock* True_BB_1 = llvm::BasicBlock::Create(TheContext,"if.then");
      std::vector<llvm::BasicBlock*> False_BB; 
      llvm::BasicBlock* False_BB_1 = llvm::BasicBlock::Create(TheContext,"if.else");
      llvm::BasicBlock* Merge_BB = llvm::BasicBlock::Create(TheContext,"if.end");
      bool condition = 1;
      for (const auto &ir : *ifinner){
        auto ifkind = ir.getAsObject()->get("kind")->getAsString()->str();     
        if(condition) {
          if(ifhaselse){
            icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,True_BB_1,False_BB_1);
          }
          else{
            icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,True_BB_1,Merge_BB);
          }
          condition = 0;
        }
        else if(ifkind == "CompoundStmt"){
          if(True_BB.size() == 0) True_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,True_BB_1,"if.then",Merge_BB,while_leave,while_enter); 
          else False_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,False_BB_1,"if.else",Merge_BB,while_leave,while_enter);
        }

        else {
          std::string key = "inner";
          std::vector<llvm::json::Value> V;
          V.push_back(ir);
          llvm::json::Object::KV a = {llvm::json::ObjectKey(key),V};
          std::initializer_list<llvm::json::Object::KV> x{a};
          auto tmp = llvm::json::Object(x);
          if(True_BB.size() == 0) True_BB = BuildCompound(&tmp,lVarName,ret_BB,True_BB_1,"if.then",Merge_BB,while_leave,while_enter); 
          else False_BB = BuildCompound(&tmp,lVarName,ret_BB,False_BB_1,"if.else",Merge_BB,while_leave,while_enter);
        }
      }

      if(False_BB.size() == 0){
        if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
        }
        Builder.CreateCondBr(icmp_ptr, True_BB[0], Merge_BB);
      }
        
      else {
        if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
        }
        Builder.CreateCondBr(icmp_ptr, True_BB[0], False_BB[0]);
      }
        
      for(int i=0;i<True_BB.size();++i)
        res_block.push_back(True_BB[i]);
      if(False_BB.size() != 0){
        for(int i=0;i<False_BB.size();++i)
          res_block.push_back(False_BB[i]);
      }
      res_block.push_back(Merge_BB);
      block_write = 0;
      Builder.SetInsertPoint(Merge_BB);
    }

    else if (kind == "WhileStmt"){
      auto whileinner = it.getAsObject()->getArray("inner"); 
      llvm::Value* icmp_ptr;
      llvm::BasicBlock* whilecon_BB;
      std::vector<llvm::BasicBlock*> whilebody_BB; 
      llvm::BasicBlock* whilebody_BB_1 = llvm::BasicBlock::Create(TheContext,"while.body");;
      llvm::BasicBlock* Merge_BB = llvm::BasicBlock::Create(TheContext,"while.end");
      bool condition = 1;
      for (const auto &ir : *whileinner){
        auto whilekind = ir.getAsObject()->get("kind")->getAsString()->str();
        if(condition){
          whilecon_BB = llvm::BasicBlock::Create(TheContext,"while.cond");
          Builder.CreateBr(whilecon_BB);
          Builder.SetInsertPoint(whilecon_BB);
          res_block.push_back(whilecon_BB);
          icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,whilebody_BB_1,Merge_BB);
          condition = 0;
        }

        else if(whilekind == "CompoundStmt" ){
          whilebody_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,whilebody_BB_1,"while.body",whilecon_BB,Merge_BB,whilecon_BB); 
        }

        else{
          std::string key = "inner";
          std::vector<llvm::json::Value> V;
          V.push_back(ir);
          llvm::json::Object::KV a = {llvm::json::ObjectKey(key),V};
          std::initializer_list<llvm::json::Object::KV> x{a};
          auto tmp = llvm::json::Object(x);
          whilebody_BB = BuildCompound(&tmp,lVarName,ret_BB,whilebody_BB_1,"while.body",whilecon_BB,Merge_BB,whilecon_BB); 
        }
      }        
      if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
      }
      Builder.CreateCondBr(icmp_ptr, whilebody_BB[0], Merge_BB);
      for(int i=0;i<whilebody_BB.size();++i)
        res_block.push_back(whilebody_BB[i]);
      res_block.push_back(Merge_BB);
      Builder.SetInsertPoint(Merge_BB);
      block_write = 0;
    }

    else if (kind == "ContinueStmt"){
      leave = while_enter;
    }

    else if (kind == "BreakStmt"){
      leave = while_leave;
    }

    else if (kind == "CompoundStmt"){
      std::vector<llvm::BasicBlock*> com_BB; 
      com_BB = BuildCompound(it.getAsObject(),lVarName,ret_BB,BB);
      for(int i=1;i<com_BB.size();++i)
        res_block.push_back(com_BB[i]);
      Builder.SetInsertPoint(com_BB[com_BB.size()-1]);
    }

    else if(kind == "DeclStmt"){
      auto dinner = it.getAsObject()->getArray("inner"); 
      std::string localVarType;
      std::string localVarName;
      const llvm::json::Object *initP;
      
      for (const auto &ir : *dinner){
        bool if_init=0; 
        localVarName = ir.getAsObject()->get("name")->getAsString()->str();
        localVarType = ir.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
        if_init = ir.getAsObject()->get("init") != 0;
        initP = ir.getAsObject();
        
        if(localVarType.find("int") != localVarType.npos)
        {
          int position = 0; 
          std::vector<int> arraynum; 
          bool is_array = 0;
          while((position = localVarType.find("[",position))!=std::string::npos)
          {
            int lpos = localVarType.find("]",position); 
            int num = stoi(localVarType.substr(position+1,lpos-position-1));
            arraynum.push_back(num); 
            position = lpos + 1; 
            is_array = 1; 
          }
          
          if(is_array)
          {
            int len = arraynum.size(); 
            llvm::ArrayType * type; 
            for(int i=len-1;i>=0;--i)
            {
              if(i == len-1)
              {
                type = llvm::ArrayType::get(Builder.getInt32Ty(), arraynum[i]);
              }
              else
              {
                type = llvm::ArrayType::get(type, arraynum[i]);
              }
              
            }
            auto l_ptr = Builder.CreateAlloca(type, 0,nullptr, localVarName);
            lVarName[localVarName] = l_ptr;
        
            if(if_init){
              auto localinner = initP->get("inner")->getAsArray();
              for (const auto &it : *localinner)
              { 
                int cnt = 0;
                array_init(0,Builder,arraynum,cnt,it.getAsObject(),l_ptr,lVarName);
              }
            }
          }

          else
          {
            auto l_ptr = Builder.CreateAlloca(llvm::Type::getInt32Ty(TheContext), 0,nullptr, localVarName); //careful!!! AddrSpace may cause bug
            lVarName[localVarName] = l_ptr;

            if(if_init)
            {
              auto initinner = initP->get("inner")->getAsArray();
              for (const auto &ir : *initinner){
                auto init_ptr = buildExp(ir.getAsObject(),Builder,lVarName);
                Builder.CreateStore(init_ptr, l_ptr);
              }
            }
          }
        }
      }
    }
  }
  if(leave != nullptr) Builder.CreateBr(leave);
  else if(!block_write && top_com) {
    Builder.CreateBr(ret_BB);
  }
  return res_block;
}

llvm::Function *buildFunctionDecl(const llvm::json::Object *O) {
  if_param = 0;
  std::map<std::string,llvm::AllocaInst *> lVarName; 
  auto tmp = O->getArray("inner");
  auto TheName = O->get("name")->getAsString()->str();
  auto if_incl = O->get("loc")->getAsObject()->get("includedFrom") != nullptr;

  std::vector <llvm::Type*> actargs;
  llvm::Function *TheFunction = TheModule.getFunction(TheName);
  if(tmp != nullptr){
    for (const auto &itmp : *tmp){
      auto kind = itmp.getAsObject()->get("kind")->getAsString()->str();
      if(kind == "ParmVarDecl") {
        auto type = itmp.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
        actargs.push_back(getType(type));
      }
    }
  }

  if (!TheFunction){
    auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
    TheFunction = llvm::Function::Create(
        llvm::FunctionType::get(getType(type,false), actargs, false),
        llvm::Function::ExternalLinkage, TheName, &TheModule);
  }

  if (!TheFunction)
    return nullptr;
  if(if_incl) return nullptr;

  // Create a new basic block to start insertion into.
  auto BB = llvm::BasicBlock::Create(TheContext, "entry",TheFunction);
  auto ret_BB = llvm::BasicBlock::Create(TheContext, "return");
  llvm::IRBuilder<> Builder(BB);

  std::string ret_str = "retval";
  auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
  auto ret_ptr = Builder.CreateAlloca(llvm::Type::getInt32Ty(TheContext), nullptr, ret_str);
  Builder.CreateStore(llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10)),ret_ptr);
  lVarName[ret_str] = ret_ptr;
  
  int arg_cnt=0; 
  for (const auto &itmp : *tmp){
    if(itmp.getAsObject()->get("kind")->getAsString()->str() == "ParmVarDecl")
    {
      auto name = itmp.getAsObject()->get("name")->getAsString()->str();
      auto Partype = itmp.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
      bool is_array = 0;
      int position = 0; 
      std::vector<int> arraynum; 
      while((position = Partype.find("[",position))!=std::string::npos)
      {
        int lpos = Partype.find("]",position); 
        int num = stoi(Partype.substr(position+1,lpos-position-1));
        arraynum.push_back(num); 
        position = lpos + 1; 
        is_array = 1; 
      }
      llvm::Value * type = nullptr; 
      if(is_array) type = llvm::ConstantInt::get(TheContext, llvm::APInt(32, std::to_string(arraynum[0]), 10));
      auto ptr = Builder.CreateAlloca(getType(Partype), type, name+".addr");
      lVarName[name] = ptr;
      auto arg_ptr = TheFunction->getArg(arg_cnt);
      Builder.CreateStore(arg_ptr, ptr);
      ++arg_cnt;
    }
  
    else if(itmp.getAsObject()->get("kind")->getAsString()->str() == "CompoundStmt")
    {
      auto com_ptr = BuildCompound(itmp.getAsObject(),lVarName,ret_BB,BB,"",nullptr,nullptr,nullptr,true);
      for(int i=1;i<com_ptr.size();++i){
        TheFunction->getBasicBlockList().push_back(com_ptr[i]);
      }
    }
  }
  
  auto ret_type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
  Builder.SetInsertPoint(ret_BB);
  ret_ptr = lVarName["retval"];
  if(ret_ptr != nullptr && ret_type.find("void") == std::string::npos){
    auto ret_val = Builder.CreateLoad(ret_ptr);
    Builder.CreateRet(ret_val);
  }
  else {
    Builder.CreateRetVoid();
  }
  TheFunction->getBasicBlockList().push_back(ret_BB);
  return nullptr;
}

llvm::Constant * Getinitnum(int dep,const llvm::json::Object *O,std::vector<int> array_num){
  auto inner_tmp = O->get("inner"); 
  const llvm::json::Array *inner;
  bool if_array_filler = 0; 
  if(inner_tmp)
  {
    inner = O->get("inner")->getAsArray();
  }
  else {
    if_array_filler = 1;
    inner = O->get("array_filler")->getAsArray();
  }

  std::vector<llvm::Constant *> init_numval;
  bool integer_init = 0; 
  for(const auto &it : *inner){
    auto kind = it.getAsObject()->get("kind")->getAsString()->str();
    if(kind == "IntegerLiteral"){
      integer_init = 1;
      auto val = it.getAsObject()->get("value")->getAsString()->str();
      init_numval.push_back(llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10)));
    }
    else if(kind == "InitListExpr"){
      init_numval.push_back(Getinitnum(dep+1,it.getAsObject(),array_num));
    }
  }

  if(if_array_filler){
    while(init_numval.size() < array_num[dep]) {
      if(integer_init) init_numval.push_back(llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10)));
      else init_numval.push_back(llvm::ConstantAggregateZero::get(llvm::Type::getInt32Ty(TheContext)));
    }
  }
  llvm::ArrayType *type;
  for(int i=array_num.size()-1;i>=dep;--i){
    if(i == array_num.size()-1)  type = llvm::ArrayType::get(llvm::Type::getInt32Ty(TheContext), array_num[dep]); 
    else type = llvm::ArrayType::get(type, array_num[dep]);
  }
  return llvm::ConstantArray::get(type,init_numval);

}

llvm::GlobalVariable *buildGlobalVarDecl(const llvm::json::Object *O){
  auto globalVarType = O->get("type")->getAsObject()->get("qualType")->getAsString()->str(); 
  auto globalVarName = O->get("name")->getAsString()->str(); 
  auto globalinner = O->getArray("inner"); 

  auto BB = llvm::BasicBlock::Create(TheContext);
  llvm::IRBuilder<> Builder(BB);

  bool is_array = 0; 
  bool is_const = 0; 

  if(globalVarType.find("const") != globalVarType.npos) is_const = 1;
  
  if(globalVarType.find("int") != globalVarType.npos)
  {
    int position = 0; 
    int num_tot = 1;
    std::vector<int> arraynum; 
    llvm::Constant * initnum;
    while((position = globalVarType.find("[",position))!=std::string::npos)
    {
      int lpos = globalVarType.find("]",position); 
      int num = stoi(globalVarType.substr(position+1,lpos-position-1));
      num_tot*=num;
      arraynum.push_back(num); 
      position = lpos + 1; 
      is_array = 1; 
    }

    if(is_array)
    {
      int len = arraynum.size(); 
      llvm::ArrayType * type; 
      for(int i=len-1;i>=0;--i)
      {
        if(i == len-1)
        {
          type = llvm::ArrayType::get(Builder.getInt32Ty(), arraynum[i]);
        }
        else
        {
          type = llvm::ArrayType::get(type, arraynum[i]);
        }
        
      }
      TheModule.getOrInsertGlobal(globalVarName, type);
      gVarName.push_back(globalVarName);
      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        for (const auto &it : *globalinner)
        { 
            if_init = 1;
            initnum = Getinitnum(0,it.getAsObject(),arraynum);
        }
      }
      if(!if_init)
      {
        auto initValue = llvm::ConstantAggregateZero::get(Builder.getInt32Ty());
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(16));
        if(is_const) globalVar->setConstant(true);
      }

      else{
          llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
          globalVar->setInitializer(initnum);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          globalVar->setAlignment(llvm::MaybeAlign(16));
          if(is_const) {
            globalVar->setConstant(true);
            globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
          }
      }
    }

    else
    {
      TheModule.getOrInsertGlobal(globalVarName, llvm::Type::getInt32Ty(TheContext)); 
      gVarName.push_back(globalVarName);

      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        for (const auto &it : *globalinner)
        { 
          if_init = 1; 
          auto init_kind = it.getAsObject()->get("kind")->getAsString()->str(); 
          std::string val;
          if(init_kind == "UnaryOperator"){
            auto uinner = it.getAsObject()->get("inner")->getAsArray(); 
            for (const auto &itt : *uinner){
              val = itt.getAsObject()->get("value")->getAsString()->str(); 
              val = "-" + val;
            }
          }
          else{
            val = it.getAsObject()->get("value")->getAsString()->str(); 
          }
          auto initValue = llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10));
          llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
          globalVar->setInitializer(initValue);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          globalVar->setAlignment(llvm::MaybeAlign(4));
          if(is_const) {
            globalVar->setConstant(true);
            globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          }
        }
      }

      if(!if_init)
      {
        auto initValue = llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10));
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(4));
        if(is_const) {
          globalVar->setConstant(true);
          globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
        }
      }
    }
    
  }
  return nullptr;
}

void buildTranslationUnitDecl(const llvm::json::Object *O) {
  if (O == nullptr)
    return;
  if (auto kind = O->get("kind")->getAsString()) {
    assert(*kind == "TranslationUnitDecl");
  } else {
    assert(0);
  }
  if (auto inner = O->getArray("inner"))
    for (const auto &it : *inner)
      if (auto P = it.getAsObject())
        if (auto kind = P->get("kind")->getAsString()) {
          if (*kind == "FunctionDecl")
            buildFunctionDecl(P);
          
          else if (*kind == "VarDecl")
            buildGlobalVarDecl(P);
        }
}
} // namespace

int main() {
  auto llvmin = llvm::MemoryBuffer::getFileOrSTDIN("-");
  auto json = llvm::json::parse(llvmin.get()->getBuffer());
  buildTranslationUnitDecl(json->getAsObject());
  TheModule.print(llvm::outs(), nullptr);
}