#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/Verifier.h>
#include <llvm/Support/JSON.h>
#include <llvm/Support/MemoryBuffer.h>
#include <llvm/Support/raw_ostream.h>
#include <algorithm>
#include <iostream>

namespace {
llvm::LLVMContext TheContext;
llvm::Module TheModule("-", TheContext);
std::vector<std::string> gVarName; 
std::map<std::string,llvm::Type *> bitcastmap;
llvm::Type* getType(std::string type,bool check_array = true){
  llvm::Type* res; 

  int type_finish;
  std::string type_tmp = type;

  type_finish = type_tmp.find("[");
  type_tmp = type_tmp.substr(0,type_finish);
  type_finish = type_tmp.find("(");
  type_tmp = type_tmp.substr(0,type_finish);

  if(type_tmp.find("int") != std::string::npos){
    res = llvm::Type::getInt32Ty(TheContext);
  }
  else if(type_tmp.find("void") != std::string::npos){
    res = llvm::Type::getVoidTy(TheContext);
  }
  else if(type_tmp.find("float") != std::string::npos){
    res = llvm::Type::getFloatTy(TheContext);
  }
  else if(type_tmp.find("char") != std::string::npos){
    res = llvm::Type::getInt8Ty(TheContext);
  }
  else if(type_tmp.find("long") != std::string::npos){
    res = llvm::Type::getInt64Ty(TheContext);
  }
  if(!check_array) return res;
  type_tmp = type;
  type_finish = type_tmp.find("[");
  if(type_finish != -1){
    int lpos = type_tmp.find("]",type_finish); 
    int num = stoi(type_tmp.substr(type_finish+1,lpos-type_finish-1));
    res = llvm::ArrayType::get(res, num);
  }
  type_tmp = type_tmp.substr(0,type_finish);
  type_finish = type.find("*");
  if(type_finish != -1){
    res = llvm::PointerType::get(res,0);
  }

  return res;
}

bool if_param;
llvm::Value* buildExp(const llvm::json::Object *O,
                      llvm::IRBuilder<> &Builder,std::map<std::string,
                      llvm::AllocaInst *> lVarName,
                      std::vector<llvm::BasicBlock*> *block_list = nullptr,
                      llvm::BasicBlock *enter = nullptr,
                      llvm::BasicBlock *leave = nullptr,
                      bool if_comming_init = false)
{
  auto kind = O->get("kind")->getAsString()->str();
  llvm::Value *LHS = nullptr; 
  llvm::Value *RHS = nullptr; 
  if(kind == "BinaryOperator"){
    auto binner = O->getArray("inner"); 
    auto opcode = O->get("opcode")->getAsString()->str(); 
    if(opcode == "&&"){
      for (const auto &it : *binner){
        llvm::BasicBlock* lhs_BB = llvm::BasicBlock::Create(TheContext,"land.lhs.true");
        llvm::BasicBlock* nowBB = Builder.GetInsertBlock();
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave); 
          if(LHS->getType()->getTypeID() == 2){
            std::string s; 
            s = it.getAsObject()->get("value")->getAsString()->str();
            if(stof(s) == 0) LHS = llvm::ConstantInt::getFalse(TheContext);
            else LHS = llvm::ConstantInt::getTrue(TheContext);
          }
          else if( !LHS->getType()->isIntegerTy(1)){
            LHS = Builder.CreateICmpNE(LHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
          }
          Builder.CreateCondBr(LHS, lhs_BB, leave);
          block_list->push_back(lhs_BB);
          Builder.SetInsertPoint(lhs_BB); 
        }
        else{
          RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave);
        }
      }
      return RHS;
    }
    
    if(opcode == "||"){
      for (const auto &it : *binner){
        llvm::BasicBlock* lhs_BB = llvm::BasicBlock::Create(TheContext,"lor.lhs.false");
        llvm::BasicBlock* nowBB = Builder.GetInsertBlock();
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,lhs_BB); 
          if( !LHS->getType()->isIntegerTy(1)){
            LHS = Builder.CreateICmpNE(LHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
          }
          Builder.CreateCondBr(LHS, enter, lhs_BB);
          block_list->push_back(lhs_BB);
          Builder.SetInsertPoint(lhs_BB); 
        }
        else{
          RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list,enter,leave);

          if(RHS->getType()->getTypeID() == 2){
            std::string s; 
            s = it.getAsObject()->get("value")->getAsString()->str();
            if(stof(s) == 0.0) RHS = llvm::ConstantInt::getFalse(TheContext);
            else RHS = llvm::ConstantInt::getTrue(TheContext);
          }
        }
      }
      return RHS;
    }

    for (const auto &it : *binner){
      if(LHS == nullptr) {
        LHS = buildExp(it.getAsObject(),Builder,lVarName,block_list);
      }

      else {
        RHS = buildExp(it.getAsObject(),Builder,lVarName,block_list);
      }
    }
    
    if(opcode == "+"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFAdd(LHS, RHS,"fadd");
      }
      return Builder.CreateAdd(LHS, RHS,"add");
    }

    else if(opcode == "-"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFSub(LHS, RHS,"fsub");
      }
      return Builder.CreateSub(LHS, RHS,"sub");
    }

    else if(opcode == "*"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFMul(LHS, RHS,"fmul");
      }
      return Builder.CreateMul(LHS, RHS,"mul");
    }

    else if(opcode == "/"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFDiv(LHS, RHS,"fdiv");
      }
      return Builder.CreateSDiv(LHS, RHS,"div");
    }

    else if(opcode == "%"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFRem(LHS, RHS,"frem");
      }
      return Builder.CreateSRem(LHS, RHS,"rem");
    }

    else if(opcode == "="){
      return Builder.CreateStore(RHS, LHS);
    }

    else if(opcode == ">"){
      return Builder.CreateICmpSGT(LHS, RHS,"cmp");
    }

    else if(opcode == "<"){
      if(LHS->getType()->getTypeID() == 2){
        return Builder.CreateFCmpOLT(LHS, RHS,"cmp");
      }
      else return Builder.CreateICmpSLT(LHS, RHS,"cmp");
    }

    else if(opcode == "=="){
      if(!RHS->getType()->isIntegerTy(32)){
        RHS = Builder.CreateZExt(RHS,llvm::Type::getInt32Ty(TheContext),RHS->getName().str()+".ext");
      }
      return Builder.CreateICmpEQ(LHS, RHS,"cmp");
    }
    
    else if(opcode == "!="){
      return Builder.CreateICmpNE(LHS, RHS,"cmp");
    }

    else if(opcode == "<="){
      return Builder.CreateICmpSLE(LHS, RHS,"cmp");
    }

    else if(opcode == ">="){
      return Builder.CreateICmpSGE(LHS, RHS,"cmp");
    }
  }

  else if(kind == "UnaryOperator"){
    auto uinner = O->getArray("inner"); 
    auto opcode = O->get("opcode")->getAsString()->str(); 

    for (const auto &it : *uinner){
      RHS = buildExp(it.getAsObject(),Builder,lVarName);
    }

    if(opcode == "-"){
      if(RHS->getType()->getTypeID() == 2){
        return Builder.CreateFNeg(RHS,"fneg");
      }
      if(!RHS->getType()->isIntegerTy(32)){
        RHS = Builder.CreateZExt(RHS,llvm::Type::getInt32Ty(TheContext),RHS->getName().str()+".ext");
      }
      LHS = llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0));
      return Builder.CreateSub(LHS, RHS,"sub");
    }
    else if(opcode == "+"){
      // LHS = llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0));
      // return Builder.CreateAdd(LHS, RHS,"add");
      return RHS;
    }
    else if(opcode == "!"){
      if(RHS->getType()->getTypeID() == 2){
        std::string s; 
        for (const auto &ir : *uinner){
          s = ir.getAsObject()->get("value")->getAsString()->str();
          break; 
        }
        if(stof(s) == 0) RHS = llvm::ConstantInt::getFalse(TheContext);
        else RHS = llvm::ConstantInt::getTrue(TheContext);
      }
      else if(!RHS->getType()->isIntegerTy(1)){
        RHS = Builder.CreateICmpNE(RHS, llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0)),"tobool");
      }
      return Builder.CreateXor(RHS,llvm::ConstantInt::getTrue(TheContext),"lnot");
    }
  }

  else if(kind == "IntegerLiteral")
  {
    auto val = O->get("value")->getAsString()->str();
    return llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10));
  }

  else if(kind == "FloatingLiteral")
  {
    auto val = O->get("value")->getAsString()->str();
    return llvm::ConstantFP::get(TheContext, llvm::APFloat(stof(val)));
  }

  else if(kind == "StringLiteral")
  {
    auto VarType = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
    std::string str = O->get("value")->getAsString()->str();
    std::vector<llvm::Constant *> strval;
    int position = 0;
    int cnt = 1; 
    while((position = VarType.find("[",position))!=std::string::npos)
    {
      int lpos = VarType.find("]",position); 
      int num = stoi(VarType.substr(position+1,lpos-position-1));
      cnt *= num;
      position = lpos + 1; 
    }
    int i;
    for(i=1;i<str.size()-1;++i)
    {
      if(str[i] == '\\'){
        if(str[i+1] == 'n') strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\n'));
        else if(str[i+1] == '\\') strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\\'));
        else strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),str[i+1]));
        ++i;
      }
      else{
        strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),str[i]));
      }
    }
    for(i=strval.size();i<cnt;++i){
      strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\0'));
    }
    TheModule.getOrInsertGlobal(".str", llvm::ArrayType::get(Builder.getInt8Ty(),cnt));
    llvm::GlobalVariable *Var = TheModule.getNamedGlobal(".str");
    Var->setLinkage(llvm::GlobalValue::PrivateLinkage);
    Var->setInitializer(llvm::ConstantArray::get(llvm::ArrayType::get(Builder.getInt8Ty(),cnt),strval));
    Var->setUnnamedAddr(llvm::GlobalValue::UnnamedAddr::Global);
    Var->setConstant(1);
    return Var;
  }

  else if(kind == "DeclRefExpr")
  {
    std::string declrefname = O->get("referencedDecl")->getAsObject()->get("name")->getAsString()->str();
    std::string declrefid = O->get("referencedDecl")->getAsObject()->get("id")->getAsString()->str();
    std::string declrefkind = O->get("referencedDecl")->getAsObject()->get("kind")->getAsString()->str();
    auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
    std::map<std::string,llvm::AllocaInst *>::iterator mit;
    mit=lVarName.find(declrefid);
    if(mit!=lVarName.end())
    {
      if(declrefkind == "ParmVarDecl" && getType(type)->getTypeID() != 11) if_param = 1;
      return lVarName[declrefid];
    }

    std::vector <std::string>::iterator it; 
    it = find(gVarName.begin(), gVarName.end(), declrefname);
    if(it != gVarName.end()){
      return TheModule.getNamedGlobal(declrefname); 
    }
  }

  else if(kind == "ImplicitCastExpr")
  {
    auto castinner = O->getArray("inner"); 
    auto castKind = O->get("castKind")->getAsString()->str();
    for (const auto &it : *castinner){
      if(castKind == "LValueToRValue"){
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        return Builder.CreateLoad(ptr);
      }
      else if(castKind == "IntegralToFloating"){
        auto kind = it.getAsObject()->get("kind")->getAsString()->str();
        if(kind == "IntegerLiteral") {
          auto val = it.getAsObject()->get("value")->getAsString()->str();
          return llvm::ConstantFP::get(TheContext, llvm::APFloat(stof(val)));
        }
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        return Builder.CreateSIToFP(ptr,llvm::Type::getFloatTy(TheContext),"conv");
      }
      else if(castKind == "FloatingToIntegral"){
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        return Builder.CreateFPToSI(ptr,llvm::Type::getInt32Ty(TheContext),"conv");
      }
      else if(castKind == "IntegralCast"){
        auto casttype = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        if(casttype == "long long"){
          return Builder.CreateIntCast(ptr,llvm::Type::getInt64Ty(TheContext),true,"conv");
        }
        else if(ptr->getType()->getIntegerBitWidth() == 8){
          return Builder.CreateSExt(ptr,llvm::Type::getInt32Ty(TheContext),"conv");
        }
        else if(ptr->getType()->getIntegerBitWidth() == 64){
          return Builder.CreateTrunc(ptr,llvm::Type::getInt32Ty(TheContext),"conv");
        }

      }
      else if(castKind == "NoOp"){
        auto ptr = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        auto tmp = Builder.CreateInBoundsGEP(ptr,
                                                    {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)), 
                                                    llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0))}); 
        return tmp; 
      }

      return buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
    }
  }

  else if(kind == "ParenExpr")
  {
    auto pinner = O->getArray("inner"); 
    for (const auto &it : *pinner){
      return buildExp(it.getAsObject(),Builder,lVarName);
    }
  }

  else if(kind == "CallExpr")
  {
    auto callinner = O->getArray("inner"); 
    std::vector <llvm::Value*> actargs;
    std::string fun_name;
    for (const auto &it : *callinner){
        if(fun_name == "") {
          auto P = it.getAsObject()->get("inner")->getAsArray();
          for(const auto &iit : *P){
            fun_name = iit.getAsObject()->get("referencedDecl")->getAsObject()->get("name")->getAsString()->str();
          }
        }
        else{
          auto arg_tmp = buildExp(it.getAsObject(),Builder,lVarName); 
          llvm::Value* res = arg_tmp;
          bool if_bitcast=0;
          if(arg_tmp->getType()->getTypeID() == 15){
            auto param_type = arg_tmp->getType()->getPointerElementType();
            if(param_type->getTypeID() == 13){
              auto cast = bitcastmap[arg_tmp->getName().str()];
              arg_tmp = Builder.CreateBitCast(arg_tmp,cast->getPointerTo());  
              if_bitcast = 1; 
            }
            param_type = arg_tmp->getType()->getPointerElementType();
            if(param_type->getTypeID() != 11){
              res = Builder.CreateInBoundsGEP(param_type, arg_tmp,
                                                    {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)), 
                                                    llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0))});              
            }
          }
          actargs.push_back(res);
        }
    }
    llvm::Function *TheFunction = TheModule.getFunction(fun_name);
    auto fun_type = TheFunction->getReturnType();
    if(fun_type->isVoidTy()){
      return Builder.CreateCall(TheFunction->getFunctionType(),TheFunction, actargs);
    }
    return Builder.CreateCall(TheFunction, actargs,"call");
  }

  else if(kind == "ArraySubscriptExpr")
  {
    if_param = 0;
    auto binner = O->getArray("inner"); 
    bool if_param_tmp = 0;
    for (const auto &it : *binner){
        if(LHS == nullptr) {
          LHS = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
          if_param_tmp = if_param;
          if_param = 0;
        }

        else {
          RHS = buildExp(it.getAsObject(),Builder,lVarName,nullptr,nullptr,nullptr,if_comming_init);
        }
    }
    auto param_type = LHS->getType()->getPointerElementType();
    if(param_type->getTypeID() == 13){
      LHS = Builder.CreateBitCast(LHS,bitcastmap[LHS->getName().str()]->getPointerTo());
    }
    if(RHS->getType()->isIntegerTy(32)){
      RHS = Builder.CreateSExt(RHS,llvm::Type::getInt64Ty(TheContext),"idxprom");
    }
    if(LHS->getType()->getTypeID() == 15 && !if_comming_init && if_param_tmp){
      return Builder.CreateInBoundsGEP(LHS, RHS,"arrayidx");
    }
    else {
      return Builder.CreateInBoundsGEP(LHS, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)), RHS},"arrayidx");
    }
  }
  return nullptr;
}

llvm::Value * make_index(int cnt,std::vector<int> &arraynum,int dep)
{
  int tmp = cnt;
  for(int i=arraynum.size()-1;i>dep;--i){
    tmp /= arraynum[i];
  } 
  return llvm::ConstantInt::get(TheContext, llvm::APInt(32, tmp%arraynum[dep]));

}

void array_init(int dep,llvm::IRBuilder<> &Builder,std::vector<int> &arraynum,int &cnt,
                const llvm::json::Object *O,llvm::Value* arr,std::map<std::string,llvm::AllocaInst *> lVarName,
                bool if_float = false){
  if(dep == arraynum.size()){
    llvm::Value* init_ptr;
    if(if_float){
      if(O != nullptr) init_ptr = buildExp(O,Builder,lVarName,nullptr,nullptr,nullptr,true);
      else init_ptr = llvm::ConstantFP::get(TheContext, llvm::APFloat(float(0.0)));
    }
    else{
      if(O != nullptr) init_ptr = buildExp(O,Builder,lVarName,nullptr,nullptr,nullptr,true);
      else init_ptr = llvm::ConstantInt::get(TheContext, llvm::APInt(32, 0));
    }

    Builder.CreateStore(init_ptr,arr);
    ++cnt;
    return ;
  }
  int tcnt = 0; 
  if(O == nullptr){
    while(tcnt < arraynum[dep]){
      ++tcnt; 
      auto gep_ptr = Builder.CreateInBoundsGEP(arr, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)),make_index(cnt,arraynum,dep)});
      array_init(dep+1,Builder,arraynum,cnt,nullptr,gep_ptr,lVarName,if_float);
    }
    return;
  }

  auto kind = O->get("kind")->getAsString()->str(); 
  auto inner_tmp = O->get("inner"); 
  const llvm::json::Array *inner;
  if(inner_tmp)
  {
    inner = O->get("inner")->getAsArray();
  }
  else {
    inner = O->get("array_filler")->getAsArray();
  }

  for (const auto &it : *inner){
    ++tcnt;
    auto gep_ptr = Builder.CreateInBoundsGEP(arr, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)),make_index(cnt,arraynum,dep)});
    auto innerkind = it.getAsObject()->get("kind")->getAsString()->str();
    if(innerkind == "ImplicitValueInitExpr"){
      --tcnt;
      continue; 
    }
    array_init(dep+1,Builder,arraynum,cnt,it.getAsObject(),gep_ptr,lVarName,if_float);
  }
  while(tcnt < arraynum[dep]){
    ++tcnt; 
    auto gep_ptr = Builder.CreateInBoundsGEP(arr, {llvm::ConstantInt::get(TheContext, llvm::APInt(64, 0)),make_index(cnt,arraynum,dep)});
    array_init(dep+1,Builder,arraynum,cnt,nullptr,gep_ptr,lVarName,if_float);
  }
}

bool if_create_return;
std::vector<llvm::BasicBlock*> BuildCompound(const llvm::json::Object *O,
                                std::map<std::string,llvm::AllocaInst *> &lVarName,
                                llvm::BasicBlock *ret_BB,
                                llvm::BasicBlock *BB = nullptr,
                                std::string BB_name = "",
                                llvm::BasicBlock *leave = nullptr,
                                llvm::BasicBlock *while_leave = nullptr,
                                llvm::BasicBlock *while_enter = nullptr,
                                bool top_com = false){
  if(BB == nullptr) BB = llvm::BasicBlock::Create(TheContext, BB_name);
  std::vector<llvm::BasicBlock*> res_block;
  res_block.push_back(BB);

  bool block_write = 0;
  llvm::IRBuilder<> Builder(BB);
  auto inner = O->getArray("inner");
  if(inner == 0){
    if(leave != nullptr) Builder.CreateBr(leave);
    return res_block; 
  }
  for (const auto &it : *inner){
    block_write = 1;
    auto kind = it.getAsObject()->get("kind")->getAsString()->str();
    // std::cout<<kind<<"\n";
    if (kind == "ReturnStmt"){
      if_create_return = 1;
      auto rinner = it.getAsObject()->getArray("inner"); 
      if(rinner!=nullptr){
        for (const auto &ir : *rinner){
          auto ret_val = buildExp(ir.getAsObject(),Builder,lVarName);
          auto ret_ptr = lVarName["retval"];
          Builder.CreateStore(ret_val,ret_ptr);
        }
      }
      else lVarName["retval"] = nullptr;
      leave = ret_BB;
    }

    else if (kind == "BinaryOperator"){
      auto opcode = it.getAsObject()->get("opcode")->getAsString()->str(); 
      auto binner = it.getAsObject()->getArray("inner"); 


      if(opcode == "=")
      {
        buildExp(it.getAsObject(),Builder,lVarName);
      }
    }

    else if (kind == "CallExpr"){
      buildExp(it.getAsObject(),Builder,lVarName);
    }

    else if (kind == "IfStmt"){
      auto ifinner = it.getAsObject()->getArray("inner"); 
      auto ifhaselse = it.getAsObject()->get("hasElse");     
      llvm::Value* icmp_ptr;
      std::vector<llvm::BasicBlock*> True_BB;
      llvm::BasicBlock* True_BB_1 = llvm::BasicBlock::Create(TheContext,"if.then");
      std::vector<llvm::BasicBlock*> False_BB; 
      llvm::BasicBlock* False_BB_1 = llvm::BasicBlock::Create(TheContext,"if.else");
      llvm::BasicBlock* Merge_BB = llvm::BasicBlock::Create(TheContext,"if.end");
      bool condition = 1;
      for (const auto &ir : *ifinner){
        auto ifkind = ir.getAsObject()->get("kind")->getAsString()->str();     
        if(condition) {
          if(ifhaselse){
            icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,True_BB_1,False_BB_1);
          }
          else{
            icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,True_BB_1,Merge_BB);
          }
          condition = 0;
        }
        else if(ifkind == "CompoundStmt"){
          if(True_BB.size() == 0) True_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,True_BB_1,"if.then",Merge_BB,while_leave,while_enter); 
          else False_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,False_BB_1,"if.else",Merge_BB,while_leave,while_enter);
        }

        else {
          std::string key = "inner";
          std::vector<llvm::json::Value> V;
          V.push_back(ir);
          llvm::json::Object::KV a = {llvm::json::ObjectKey(key),V};
          std::initializer_list<llvm::json::Object::KV> x{a};
          auto tmp = llvm::json::Object(x);
          if(True_BB.size() == 0) True_BB = BuildCompound(&tmp,lVarName,ret_BB,True_BB_1,"if.then",Merge_BB,while_leave,while_enter); 
          else False_BB = BuildCompound(&tmp,lVarName,ret_BB,False_BB_1,"if.else",Merge_BB,while_leave,while_enter);
        }
      }
      if(False_BB.size() == 0){
        if(icmp_ptr->getType()->getTypeID() == 2){
          std::string s; 
          for (const auto &ir : *ifinner){
            s = ir.getAsObject()->get("value")->getAsString()->str();
            break; 
          }
          if(stof(s) == 0) icmp_ptr = llvm::ConstantInt::getFalse(TheContext);
          else icmp_ptr = llvm::ConstantInt::getTrue(TheContext);
        }
        else if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(icmp_ptr->getType()->getIntegerBitWidth(), 0)),"tobool");
        }
        Builder.CreateCondBr(icmp_ptr, True_BB[0], Merge_BB);
      }
        
      else {
        if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(icmp_ptr->getType()->getIntegerBitWidth(), 0)),"tobool");
        }
        Builder.CreateCondBr(icmp_ptr, True_BB[0], False_BB[0]);
      }
      for(int i=0;i<True_BB.size();++i)
        res_block.push_back(True_BB[i]);
      if(False_BB.size() != 0){
        for(int i=0;i<False_BB.size();++i)
          res_block.push_back(False_BB[i]);
      }
      res_block.push_back(Merge_BB);
      block_write = 0;
      Builder.SetInsertPoint(Merge_BB);
    }

    else if (kind == "WhileStmt"){
      auto whileinner = it.getAsObject()->getArray("inner"); 
      llvm::Value* icmp_ptr;
      llvm::BasicBlock* whilecon_BB;
      std::vector<llvm::BasicBlock*> whilebody_BB; 
      llvm::BasicBlock* whilebody_BB_1 = llvm::BasicBlock::Create(TheContext,"while.body");;
      llvm::BasicBlock* Merge_BB = llvm::BasicBlock::Create(TheContext,"while.end");
      bool condition = 1;
      for (const auto &ir : *whileinner){
        auto whilekind = ir.getAsObject()->get("kind")->getAsString()->str();
        if(condition){
          whilecon_BB = llvm::BasicBlock::Create(TheContext,"while.cond");
          Builder.CreateBr(whilecon_BB);
          Builder.SetInsertPoint(whilecon_BB);
          res_block.push_back(whilecon_BB);
          icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,whilebody_BB_1,Merge_BB);
          condition = 0;
        }

        else if(whilekind == "CompoundStmt" ){
          whilebody_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,whilebody_BB_1,"while.body",whilecon_BB,Merge_BB,whilecon_BB); 
        }

        else{
          std::string key = "inner";
          std::vector<llvm::json::Value> V;
          V.push_back(ir);
          llvm::json::Object::KV a = {llvm::json::ObjectKey(key),V};
          std::initializer_list<llvm::json::Object::KV> x{a};
          auto tmp = llvm::json::Object(x);
          whilebody_BB = BuildCompound(&tmp,lVarName,ret_BB,whilebody_BB_1,"while.body",whilecon_BB,Merge_BB,whilecon_BB); 
        }
      }        
      if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(icmp_ptr->getType()->getIntegerBitWidth(), 0)),"tobool");
      }
      Builder.CreateCondBr(icmp_ptr, whilebody_BB[0], Merge_BB);
      for(int i=0;i<whilebody_BB.size();++i)
        res_block.push_back(whilebody_BB[i]);
      res_block.push_back(Merge_BB);
      Builder.SetInsertPoint(Merge_BB);
      block_write = 0;
    }

    else if(kind == "DoStmt"){
      auto doinner = it.getAsObject()->getArray("inner");
      bool condition = 0;
      llvm::Value* icmp_ptr;
      std::vector<llvm::BasicBlock*> dobody_BB; 
      llvm::BasicBlock* dobody_BB_1 = llvm::BasicBlock::Create(TheContext,"do.body");;
      llvm::BasicBlock* docon_BB;
      llvm::BasicBlock* Merge_BB = llvm::BasicBlock::Create(TheContext,"do.end");
      for (const auto &ir : *doinner){
        auto whilekind = ir.getAsObject()->get("kind")->getAsString()->str();
        if(condition){
          docon_BB = llvm::BasicBlock::Create(TheContext,"do.cond");
          Builder.SetInsertPoint(dobody_BB_1);
          Builder.CreateBr(docon_BB);
          Builder.SetInsertPoint(docon_BB);
          res_block.push_back(docon_BB);
          icmp_ptr = buildExp(ir.getAsObject(),Builder,lVarName,&res_block,dobody_BB_1,Merge_BB);
          condition = 0;
        }

        else if(whilekind == "CompoundStmt" ){
          Builder.CreateBr(dobody_BB_1);
          dobody_BB = BuildCompound(ir.getAsObject(),lVarName,ret_BB,dobody_BB_1,"do.body"); 
          for(int i=0;i<dobody_BB.size();++i)
            res_block.push_back(dobody_BB[i]);
          condition = 1;
        }
      }
      if( !icmp_ptr->getType()->isIntegerTy(1)){
          icmp_ptr = Builder.CreateICmpNE(icmp_ptr, llvm::ConstantInt::get(TheContext, llvm::APInt(icmp_ptr->getType()->getIntegerBitWidth(), 0)),"tobool");
      }
      Builder.CreateCondBr(icmp_ptr, dobody_BB[0], Merge_BB);
      res_block.push_back(Merge_BB);
      Builder.SetInsertPoint(Merge_BB);
    }

    else if (kind == "ContinueStmt"){
      leave = while_enter;
    }

    else if (kind == "BreakStmt"){
      leave = while_leave;
    }

    else if (kind == "CompoundStmt"){
      std::vector<llvm::BasicBlock*> com_BB; 
      com_BB = BuildCompound(it.getAsObject(),lVarName,ret_BB,Builder.GetInsertBlock());
      for(int i=1;i<com_BB.size();++i)
        res_block.push_back(com_BB[i]);
      Builder.SetInsertPoint(com_BB[com_BB.size()-1]);
    }

    else if(kind == "DeclStmt"){
      auto dinner = it.getAsObject()->getArray("inner"); 
      std::string localVarType;
      std::string localVarName;
      std::string localid;
      const llvm::json::Object *initP;
      
      for (const auto &ir : *dinner){
        bool if_init=0; 
        localVarName = ir.getAsObject()->get("name")->getAsString()->str();
        localVarType = ir.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
        localid = ir.getAsObject()->get("id")->getAsString()->str();
        if_init = ir.getAsObject()->get("init") != 0;
        initP = ir.getAsObject();
        
        if(localVarType.find("int") != localVarType.npos)
        {
          int position = 0; 
          std::vector<int> arraynum; 
          bool is_array = 0;
          while((position = localVarType.find("[",position))!=std::string::npos)
          {
            int lpos = localVarType.find("]",position); 
            int num = stoi(localVarType.substr(position+1,lpos-position-1));
            arraynum.push_back(num); 
            position = lpos + 1; 
            is_array = 1; 
          }
          
          if(is_array)
          {
            int len = arraynum.size(); 
            llvm::ArrayType * type; 
            for(int i=len-1;i>=0;--i)
            {
              if(i == len-1)
              {
                type = llvm::ArrayType::get(Builder.getInt32Ty(), arraynum[i]);
              }
              else
              {
                type = llvm::ArrayType::get(type, arraynum[i]);
              }
              
            }
            auto l_ptr = Builder.CreateAlloca(type, 0,nullptr, localVarName);
            lVarName[localid] = l_ptr;
        
            if(if_init){
              auto localinner = initP->get("inner")->getAsArray();
              for (const auto &it : *localinner)
              { 
                int cnt = 0;
                array_init(0,Builder,arraynum,cnt,it.getAsObject(),l_ptr,lVarName);
              }
            }
          }

          else
          {
            auto l_ptr = Builder.CreateAlloca(llvm::Type::getInt32Ty(TheContext), 0,nullptr, localVarName); //careful!!! AddrSpace may cause bug
            lVarName[localid] = l_ptr;

            if(if_init)
            {
              auto initinner = initP->get("inner")->getAsArray();
              for (const auto &ir : *initinner){
                auto init_ptr = buildExp(ir.getAsObject(),Builder,lVarName);
                Builder.CreateStore(init_ptr, l_ptr);
              }
            }
          }
        }

        else if(localVarType.find("long") != localVarType.npos){
          auto l_ptr = Builder.CreateAlloca(llvm::Type::getInt64Ty(TheContext), 0,nullptr, localVarName); //careful!!! AddrSpace may cause bug
          lVarName[localid] = l_ptr;

          if(if_init)
          {
            auto initinner = initP->get("inner")->getAsArray();
            for (const auto &ir : *initinner){
              auto init_ptr = buildExp(ir.getAsObject(),Builder,lVarName);
              Builder.CreateStore(init_ptr, l_ptr);
            }
          }
        }

        else if(localVarType.find("char") != localVarType.npos){
          int position = 0; 
          std::vector<int> arraynum; 
          bool is_array = 0;
          int cnt = 1; 
          while((position = localVarType.find("[",position))!=std::string::npos)
          {
            int lpos = localVarType.find("]",position); 
            int num = stoi(localVarType.substr(position+1,lpos-position-1));
            arraynum.push_back(num); 
            cnt *= num; 
            position = lpos + 1; 
            is_array = 1; 
          }
          
          if(is_array)
          {
            int len = arraynum.size(); 
            llvm::ArrayType * type; 
            for(int i=len-1;i>=0;--i)
            {
              if(i == len-1)
              {
                type = llvm::ArrayType::get(Builder.getInt8Ty(), arraynum[i]);
              }
              else
              {
                type = llvm::ArrayType::get(type, arraynum[i]);
              }
              
            }
            auto l_ptr = Builder.CreateAlloca(type, 0,nullptr, localVarName);
            lVarName[localid] = l_ptr;
        
            if(if_init){
              auto localinner = initP->get("inner")->getAsArray();
              for (const auto &it : *localinner)
              { 
                std::string str = it.getAsObject()->get("value")->getAsString()->str();
                std::vector<llvm::Constant *> strval;
                int i;
                for(i=1;i<str.size()-1;++i)
                {
                  if(str[i] == '\\'){
                    if(str[i+1] == 'n') strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\n'));
                    else if(str[i+1] == '\\') strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\\'));
                    else strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),str[i+1]));
                    ++i;
                  }
                  else{
                    strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),str[i]));
                  }
                }
                for(i=strval.size();i<cnt;++i){
                  strval.push_back(llvm::ConstantInt::get(Builder.getInt8Ty(),'\0'));
                }
                llvm::Value *init = llvm::ConstantArray::get(llvm::ArrayType::get(Builder.getInt8Ty(),cnt),strval);
                Builder.CreateStore(init,l_ptr);
              }
            }
          }          
        }

        else{
          int position = 0; 
          std::vector<int> arraynum; 
          bool is_array = 0;
          while((position = localVarType.find("[",position))!=std::string::npos)
          {
            int lpos = localVarType.find("]",position); 
            int num = stoi(localVarType.substr(position+1,lpos-position-1));
            arraynum.push_back(num); 
            position = lpos + 1; 
            is_array = 1; 
          }
          
          if(is_array)
          {
            int len = arraynum.size(); 
            llvm::ArrayType * type; 
            for(int i=len-1;i>=0;--i)
            {
              if(i == len-1)
              {
                type = llvm::ArrayType::get(Builder.getFloatTy(), arraynum[i]);
              }
              else
              {
                type = llvm::ArrayType::get(type, arraynum[i]);
              }
              
            }
            auto l_ptr = Builder.CreateAlloca(type, 0,nullptr, localVarName);
            lVarName[localid] = l_ptr;
        
            if(if_init){
              auto localinner = initP->get("inner")->getAsArray();
              for (const auto &it : *localinner)
              { 
                int cnt = 0;
                array_init(0,Builder,arraynum,cnt,it.getAsObject(),l_ptr,lVarName,true);
              }
            }
          }
          else
          {
            auto l_ptr = Builder.CreateAlloca(llvm::Type::getFloatTy(TheContext), 0,nullptr, localVarName); //careful!!! AddrSpace may cause bug
            lVarName[localid] = l_ptr;

            if(if_init)
            {
              auto initinner = initP->get("inner")->getAsArray();
              for (const auto &ir : *initinner){
                auto init_ptr = buildExp(ir.getAsObject(),Builder,lVarName);
                Builder.CreateStore(init_ptr, l_ptr);
              }
            }
          }
        }
      }
    }
  }
  if(leave != nullptr) Builder.CreateBr(leave);
  else if((!block_write  || !if_create_return)&& top_com) {
    Builder.CreateBr(ret_BB);
  }
  return res_block;
}

llvm::Function *buildFunctionDecl(const llvm::json::Object *O) {
  if_param = 0;
  std::map<std::string,llvm::AllocaInst *> lVarName; 
  auto tmp = O->getArray("inner");
  auto TheName = O->get("name")->getAsString()->str();
  auto if_incl = O->get("loc")->getAsObject()->get("includedFrom") != nullptr;
  auto implicit_get = O->get("isImplicit"); 
  if(implicit_get != nullptr) return nullptr;
  std::vector <llvm::Type*> actargs;
  llvm::Function *TheFunction = TheModule.getFunction(TheName);
  if(tmp != nullptr){
    for (const auto &itmp : *tmp){
      auto kind = itmp.getAsObject()->get("kind")->getAsString()->str();
      if(kind == "ParmVarDecl") {
        auto type = itmp.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
        actargs.push_back(getType(type));
      }
    }
  }

  if (!TheFunction){
    auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
    TheFunction = llvm::Function::Create(
        llvm::FunctionType::get(getType(type,false), actargs, false),
        llvm::Function::ExternalLinkage, TheName, &TheModule);
  }

  if (!TheFunction)
    return nullptr;
  if(if_incl) return nullptr;
  //std::cout<<TheName<<"\n";
  // Create a new basic block to start insertion into.
  auto BB = llvm::BasicBlock::Create(TheContext, "entry",TheFunction);
  auto ret_BB = llvm::BasicBlock::Create(TheContext, "return");
  llvm::IRBuilder<> Builder(BB);

  std::string ret_str = "retval";
  llvm::AllocaInst * ret_ptr;
  auto type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
  auto rettype = getType(type,false);
  if(rettype->getTypeID() == 11){
    if(rettype->getIntegerBitWidth() == 32){
      ret_ptr = Builder.CreateAlloca(llvm::Type::getInt32Ty(TheContext), nullptr, ret_str);
      Builder.CreateStore(llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10)),ret_ptr);
    }
    else{
      ret_ptr = Builder.CreateAlloca(llvm::Type::getInt64Ty(TheContext), nullptr, ret_str);
      Builder.CreateStore(llvm::ConstantInt::get(TheContext, llvm::APInt(64, "0", 10)),ret_ptr);
    }
  }
  else  if(rettype->getTypeID() == 2){
    ret_ptr = Builder.CreateAlloca(llvm::Type::getFloatTy(TheContext), nullptr, ret_str);
  }
  lVarName[ret_str] = ret_ptr;
  
  int arg_cnt=0; 
  for (const auto &itmp : *tmp){
    if(itmp.getAsObject()->get("kind")->getAsString()->str() == "ParmVarDecl")
    {
      auto name = itmp.getAsObject()->get("name")->getAsString()->str();
      auto Partype = itmp.getAsObject()->get("type")->getAsObject()->get("qualType")->getAsString()->str();
      auto id = itmp.getAsObject()->get("id")->getAsString()->str();
      bool is_array = 0;
      int position = 0; 
      std::vector<int> arraynum; 
      while((position = Partype.find("[",position))!=std::string::npos)
      {
        int lpos = Partype.find("]",position); 
        int num = stoi(Partype.substr(position+1,lpos-position-1));
        arraynum.push_back(num); 
        position = lpos + 1; 
        is_array = 1; 
      }
      llvm::Value * type = nullptr; 
      if(is_array) type = llvm::ConstantInt::get(TheContext, llvm::APInt(32, std::to_string(arraynum[0]), 10));
      auto ptr = Builder.CreateAlloca(getType(Partype), type, name+".addr");
      lVarName[id] = ptr;
      auto arg_ptr = TheFunction->getArg(arg_cnt);
      Builder.CreateStore(arg_ptr, ptr);
      ++arg_cnt;
    }
  
    else if(itmp.getAsObject()->get("kind")->getAsString()->str() == "CompoundStmt")
    {
      if_create_return = 0; 
      auto com_ptr = BuildCompound(itmp.getAsObject(),lVarName,ret_BB,BB,"",nullptr,nullptr,nullptr,true);
      for(int i=1;i<com_ptr.size();++i){
        TheFunction->getBasicBlockList().push_back(com_ptr[i]);
      }
    }
  }

  auto ret_type = O->get("type")->getAsObject()->get("qualType")->getAsString()->str();
  Builder.SetInsertPoint(ret_BB);
  ret_ptr = lVarName["retval"];
  if(ret_ptr != nullptr && ret_type.find("void") == std::string::npos){
    auto ret_val = Builder.CreateLoad(ret_ptr);
    Builder.CreateRet(ret_val);
  }
  else {
    Builder.CreateRetVoid();
  }
  TheFunction->getBasicBlockList().push_back(ret_BB);
  return nullptr;
}

llvm::Constant * Getinitnum(int dep,const llvm::json::Object *O,std::vector<int> array_num,bool if_float = false){
  auto inner_tmp = O->get("inner"); 
  const llvm::json::Array *inner;
  bool if_array_filler = 0; 
  if(inner_tmp)
  {
    inner = O->get("inner")->getAsArray();
  }
  else {
    if_array_filler = 1;
    inner = O->get("array_filler")->getAsArray();
  }

  std::vector<llvm::Constant *> init_numval;
  bool integer_init = 0; 
  for(const auto &it : *inner){
    auto kind = it.getAsObject()->get("kind")->getAsString()->str();
    if(kind == "IntegerLiteral"){
      integer_init = 1;
      auto val = it.getAsObject()->get("value")->getAsString()->str();
      if(if_float) init_numval.push_back(llvm::ConstantFP::get(TheContext,llvm::APFloat(stof(val))));
      else init_numval.push_back(llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10)));
    }
    else if(kind == "InitListExpr"){
      init_numval.push_back(Getinitnum(dep+1,it.getAsObject(),array_num,if_float));
    }
  }

  if(if_array_filler){
    while(init_numval.size() < array_num[dep]) {
      if(integer_init) {
        if(if_float) init_numval.push_back(llvm::ConstantFP::get(TheContext,llvm::APFloat(0.0)));
        else init_numval.push_back(llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10)));
      }
      else {
        if(if_float) init_numval.push_back(llvm::ConstantAggregateZero::get(llvm::Type::getFloatTy(TheContext)));
        else init_numval.push_back(llvm::ConstantAggregateZero::get(llvm::Type::getInt32Ty(TheContext)));
      }
    }
  }
  llvm::ArrayType *type;
  for(int i=array_num.size()-1;i>=dep;--i){
    if(i == array_num.size()-1)  {
      if(if_float) type = llvm::ArrayType::get(llvm::Type::getFloatTy(TheContext), array_num[dep]); 
      else type = llvm::ArrayType::get(llvm::Type::getInt32Ty(TheContext), array_num[dep]); 
    }
    else type = llvm::ArrayType::get(type, array_num[dep]);
  }
  return llvm::ConstantArray::get(type,init_numval);

}

bool if_int;
llvm::Constant * Getinitnum_list(int dep,const llvm::json::Object *O,std::vector<int> array_num,bool if_float = false){
  auto inner_tmp = O->get("inner"); 
  const llvm::json::Array *inner;
  bool if_array_filler = 0; 
  if(inner_tmp)
  {
    inner = O->get("inner")->getAsArray();
  }
  else {
    if_array_filler = 1;
    inner = O->get("array_filler")->getAsArray();
  }

  std::vector<llvm::Constant *> init_numval;
  std::vector<llvm::Type *> init_type;
  bool integer_init = 0; 
  for(const auto &it : *inner){
    auto kind = it.getAsObject()->get("kind")->getAsString()->str();
    if(kind == "IntegerLiteral"){
      if_int = 1;
      integer_init = 1;
      auto val = it.getAsObject()->get("value")->getAsString()->str();
      if(if_float) {
        init_numval.push_back(llvm::ConstantFP::get(TheContext,llvm::APFloat(stof(val))));
        init_type.push_back(llvm::Type::getFloatTy(TheContext));
      }
      else {
        init_numval.push_back(llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10)));
        init_type.push_back(llvm::Type::getInt32Ty(TheContext));
      }
    }
    else if(kind == "InitListExpr"){
      init_numval.push_back(Getinitnum_list(dep+1,it.getAsObject(),array_num,if_float));
      init_type.push_back(init_numval[init_numval.size()-1]->getType());
    }
  }
  if(if_array_filler){
    if(init_numval.size() < array_num[dep]) {
      if(if_float) {
        init_numval.push_back(llvm::Constant::getNullValue(llvm::ArrayType::get(llvm::Type::getFloatTy(TheContext), array_num[dep]-init_numval.size())));
        init_type.push_back(llvm::ArrayType::get(llvm::Type::getFloatTy(TheContext), array_num[dep]-init_numval.size()+1));
      }
      else {
        init_numval.push_back(llvm::Constant::getNullValue(llvm::ArrayType::get(llvm::IntegerType::get(TheContext, 32), array_num[dep]-init_numval.size())));
        init_type.push_back(llvm::ArrayType::get(llvm::IntegerType::get(TheContext, 32), array_num[dep]-init_numval.size()+1));
      }

    }
  }
  // llvm::ArrayType *type;
  // for(int i=array_num.size()-1;i>=dep;--i){
  //   if(i == array_num.size()-1)  {
  //     if(if_float) type = llvm::ArrayType::get(llvm::Type::getFloatTy(TheContext), array_num[dep]); 
  //     else type = llvm::ArrayType::get(llvm::Type::getInt32Ty(TheContext), array_num[dep]); 
  //   }
  //   else type = llvm::ArrayType::get(type, array_num[dep]);
  // }

  llvm::StructType *type = llvm::StructType::get(TheContext, init_type);
  return llvm::ConstantStruct::get(type,init_numval);

}


std::map<std::string,std::string> constval;
float cal_val(const llvm::json::Object *O){
  float res; 
  auto kind = O->get("kind")->getAsString()->str();
  if(kind == "BinaryOperator"){
    double ls = 1.0,rs = 1.0; 
    bool ls_do = 1; 
    auto inner = O->get("inner")->getAsArray();
    for (const auto &it : *inner){
      if(ls_do){
        ls_do = 0; 
        ls = cal_val(it.getAsObject()); 
      } 
      else rs = cal_val(it.getAsObject());
    }
    
    auto opcode = O->get("opcode")->getAsString()->str(); 
    if(opcode == "*") return ls * rs;
    else if(opcode == "+") return ls + rs;
  }

  else if(kind == "ImplicitCastExpr"){
    auto inner = O->get("inner")->getAsArray();
    for (const auto &it : *inner){
      return cal_val(it.getAsObject());
    }
  }


  else if(kind == "IntegerLiteral"){
    auto val = O->get("value")->getAsString()->str();
    return stof(val);
  }

  else if(kind == "DeclRefExpr"){
    auto name = O->get("referencedDecl")->getAsObject()->get("name")->getAsString()->str(); 
    return stof(constval[name]);
  }
  return 0;
}

llvm::GlobalVariable *buildGlobalVarDecl(const llvm::json::Object *O){
  auto globalVarType = O->get("type")->getAsObject()->get("qualType")->getAsString()->str(); 
  auto globalVarName = O->get("name")->getAsString()->str(); 
  auto globalinner = O->getArray("inner"); 

  auto BB = llvm::BasicBlock::Create(TheContext);
  llvm::IRBuilder<> Builder(BB);

  bool is_array = 0; 
  bool is_const = 0; 
  if_int = 0;
  if(globalVarType.find("const") != globalVarType.npos) is_const = 1;
  
  if(globalVarType.find("int") != globalVarType.npos)
  {
    int position = 0; 
    int num_tot = 1;
    std::vector<int> arraynum; 
    llvm::Constant * initnum;
    while((position = globalVarType.find("[",position))!=std::string::npos)
    {
      int lpos = globalVarType.find("]",position); 
      int num = stoi(globalVarType.substr(position+1,lpos-position-1));
      num_tot*=num;
      arraynum.push_back(num); 
      position = lpos + 1; 
      is_array = 1; 
    }

    if(is_array)
    {
      int len = arraynum.size(); 
      llvm::ArrayType * type; 
      for(int i=len-1;i>=0;--i)
      {
        if(i == len-1)
        {
          type = llvm::ArrayType::get(Builder.getInt32Ty(), arraynum[i]);
        }
        else
        {
          type = llvm::ArrayType::get(type, arraynum[i]);
        }
        
      }
      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        for (const auto &it : *globalinner)
        { 
            if_init = 1;
            initnum = Getinitnum_list(0,it.getAsObject(),arraynum);
        }
      }
      if(if_init && if_int) {
        TheModule.getOrInsertGlobal(globalVarName, initnum->getType());
        bitcastmap[globalVarName] = type;
      }
      else TheModule.getOrInsertGlobal(globalVarName, type);
      gVarName.push_back(globalVarName);
      if(!if_init)
      {
        auto initValue = llvm::ConstantAggregateZero::get(Builder.getInt32Ty());
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(16));
        if(is_const) globalVar->setConstant(true);
      }

      else{
          llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
          globalVar->setInitializer(initnum);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          globalVar->setAlignment(llvm::MaybeAlign(16));
          if(is_const) {
            globalVar->setConstant(true);
            globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
          }
      }
    }

    else
    {
      TheModule.getOrInsertGlobal(globalVarName, llvm::Type::getInt32Ty(TheContext)); 
      gVarName.push_back(globalVarName);

      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        for (const auto &it : *globalinner)
        { 
          if_init = 1; 
          auto init_kind = it.getAsObject()->get("kind")->getAsString()->str(); 
          std::string val;
          if(init_kind == "UnaryOperator"){
            auto uinner = it.getAsObject()->get("inner")->getAsArray(); 
            for (const auto &itt : *uinner){
              val = itt.getAsObject()->get("value")->getAsString()->str(); 
              val = "-" + val;
            }
          }

          else if(init_kind == "ImplicitCastExpr"){
            auto impinner = it.getAsObject()->get("inner")->getAsArray(); 
            for(const auto &itt : *impinner){
              auto initt_kind = itt.getAsObject()->get("kind")->getAsString()->str(); 
              if(initt_kind == "UnaryOperator"){
                auto uinner = itt.getAsObject()->get("inner")->getAsArray(); 
                for (const auto &ittt : *uinner){
                  val = ittt.getAsObject()->get("value")->getAsString()->str(); 
                  val = "-" + val;
                }
              }
              else{
                val = itt.getAsObject()->get("value")->getAsString()->str(); 
                if(int pos = val.find("E") != std::string::npos) {
                  val = std::string("1000000000");
                }
                if(int pos = val.find(".") != std::string::npos) val = val.substr(0,pos);
              }
              
            }
          }

          else if(init_kind == "BinaryOperator"){
            auto calval = cal_val(it.getAsObject()); 
            val = std::to_string(calval);
            if(int pos = val.find(".") != std::string::npos) val = val.substr(0,pos);
          }

          else{
            val = it.getAsObject()->get("value")->getAsString()->str(); 
          }
          constval[globalVarName] = val;
          auto initValue = llvm::ConstantInt::get(TheContext, llvm::APInt(32, val, 10));
          llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
          globalVar->setInitializer(initValue);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          globalVar->setAlignment(llvm::MaybeAlign(4));
          if(is_const) {
            globalVar->setConstant(true);
            globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          }
        }
      }

      if(!if_init)
      {
        auto initValue = llvm::ConstantInt::get(TheContext, llvm::APInt(32, "0", 10));
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(4));
        if(is_const) {
          globalVar->setConstant(true);
          globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
        }
      }
    }
    
  }
  // FLOAT
  else{
    int position = 0; 
    int num_tot = 1;
    std::vector<int> arraynum; 
    llvm::Constant * initnum;
    while((position = globalVarType.find("[",position))!=std::string::npos)
    {
      int lpos = globalVarType.find("]",position); 
      int num = stoi(globalVarType.substr(position+1,lpos-position-1));
      num_tot*=num;
      arraynum.push_back(num); 
      position = lpos + 1; 
      is_array = 1; 
    }

    if(is_array)
    {
      int len = arraynum.size(); 
      llvm::ArrayType * type; 
      for(int i=len-1;i>=0;--i)
      {
        if(i == len-1)
        {
          type = llvm::ArrayType::get(Builder.getFloatTy(), arraynum[i]);
        }
        else
        {
          type = llvm::ArrayType::get(type, arraynum[i]);
        }
        
      }
      TheModule.getOrInsertGlobal(globalVarName, type);
      gVarName.push_back(globalVarName);
      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        for (const auto &it : *globalinner)
        { 
            if_init = 1;
            initnum = Getinitnum(0,it.getAsObject(),arraynum,true);
        }
      }
      if(!if_init)
      {
        auto initValue = llvm::ConstantAggregateZero::get(Builder.getFloatTy());
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(16));
        if(is_const) globalVar->setConstant(true);
      }

      else{
          llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
          globalVar->setInitializer(initnum);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
          globalVar->setAlignment(llvm::MaybeAlign(16));
          if(is_const) {
            globalVar->setConstant(true);
            globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
          }
      }
    }

    else
    {
      TheModule.getOrInsertGlobal(globalVarName, llvm::Type::getFloatTy(TheContext)); 
      gVarName.push_back(globalVarName);

      bool if_init = 0; 
      if(globalinner!=nullptr)
      {
        if_init = 1; 
        std::string val;
        for (const auto &itt : *globalinner)
        { 
          auto impinner = itt.getAsObject()->get("inner")->getAsArray(); 
          auto impkind = itt.getAsObject()->get("kind")->getAsString()->str(); 
          if(impkind == "ImplicitCastExpr"){
            for(const auto &it : *impinner){
              
              auto init_kind = it.getAsObject()->get("kind")->getAsString()->str(); 
              if(init_kind == "UnaryOperator"){
                auto uinner = it.getAsObject()->get("inner")->getAsArray(); 
                for (const auto &itt : *uinner){
                  val = itt.getAsObject()->get("value")->getAsString()->str(); 
                  val = "-" + val;
                }
              }
              else{
                val = it.getAsObject()->get("value")->getAsString()->str(); 
              }
            }
          }
          else if(impkind == "BinaryOperator"){
            auto calval = cal_val(itt.getAsObject()); 
            val = std::to_string(calval);
          }
        }
        constval[globalVarName] = val; 
        auto initValue = llvm::ConstantFP::get(TheContext, llvm::APFloat(stof(val)));
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(4));
        if(is_const) {
          globalVar->setConstant(true);
          globalVar->setLinkage(llvm::GlobalValue::ExternalLinkage);
        }
      }

      if(!if_init)
      {
        auto initValue = llvm::ConstantFP::get(TheContext, llvm::APFloat(0.0));
        llvm::GlobalVariable *globalVar = TheModule.getNamedGlobal(globalVarName); 
        globalVar->setInitializer(initValue);
        globalVar->setLinkage(llvm::GlobalValue::CommonLinkage);
        globalVar->setAlignment(llvm::MaybeAlign(4));
        if(is_const) {
          globalVar->setConstant(true);
          globalVar->setLinkage(llvm::GlobalValue::InternalLinkage);
        }
      }
    }
  }
  return nullptr;
}

void buildTranslationUnitDecl(const llvm::json::Object *O) {
  if (O == nullptr)
    return;
  if (auto kind = O->get("kind")->getAsString()) {
    assert(*kind == "TranslationUnitDecl");
  } else {
    assert(0);
  }
  if (auto inner = O->getArray("inner"))
    for (const auto &it : *inner)
      if (auto P = it.getAsObject())
        if (auto kind = P->get("kind")->getAsString()) {
          if (*kind == "FunctionDecl")
            buildFunctionDecl(P);
          
          else if (*kind == "VarDecl")
            buildGlobalVarDecl(P);
        }
}
} // namespace

int main() {
  auto llvmin = llvm::MemoryBuffer::getFileOrSTDIN("-");
  auto json = llvm::json::parse(llvmin.get()->getBuffer());
  buildTranslationUnitDecl(json->getAsObject());

  for(auto &fun:TheModule.getFunctionList()){
    llvm::BasicBlock *ready = llvm::BasicBlock::Create(TheContext,"ready");
    for(auto &block : fun.getBasicBlockList()){
      std::vector<llvm::Instruction*> toRemove; 
      auto iter = block.getInstList().begin(); 
      while(iter != block.getInstList().end()){
        auto inst = &*iter; 
        iter++; 
        if(inst->getOpcode() == llvm::Instruction::Alloca) toRemove.push_back(inst); 
      }
      for(auto &inst : toRemove){
        inst->removeFromParent();
        ready->getInstList().push_back(inst); 
      }
    }
    llvm::BasicBlock &entry = fun.getEntryBlock(); 
    entry.getInstList().splice(entry.begin(),ready->getInstList());
  }

  TheModule.print(llvm::outs(), nullptr);
}