//test local var define
int main(){
    int a, b0, _c;
    a = 1;
    b0 = 2;
    _c = 3;
    return b0 + _c;
}