int main(){
    return 3;
}