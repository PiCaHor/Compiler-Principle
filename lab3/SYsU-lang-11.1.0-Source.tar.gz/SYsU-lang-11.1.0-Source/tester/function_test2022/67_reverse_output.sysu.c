#include <sysy/sylib.h>
void reverse(int n) {
	int next;
	if (n <= 1) {
		next=getint();
		putint(next);
	}
	else {
		next=getint();
		reverse(n-1);
		putint(next);
	}
}

int main() {
	int i=200;
	reverse(i);
	return 0;
}
