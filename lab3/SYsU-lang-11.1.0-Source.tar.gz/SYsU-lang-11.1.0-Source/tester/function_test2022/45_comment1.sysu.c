//test comment
int main(){
    int a;
    a = 5;
    //int b = 4;
    //a = b + a;
    /*/*
        b = 1;
        // b = 2
    */
    return a;
}