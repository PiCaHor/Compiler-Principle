int defn(){
    return 4;
}

int main(){
    int a=defn();
    return a;
}