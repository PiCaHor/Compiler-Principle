#include <sysy/sylib.h>
// Count how many alpha in a string
int main() {
    int string[500];
    int temp;
    int i;
    int count;
    count = 0;
    i = 0;
    temp = 0;
    while (temp != 10) {
        temp = getch();
        if (temp > 40 && temp < 91 || temp > 96 && temp < 123) {
            count = count + 1;
        }
        i = i + 1;
    }
    putint(count);
    return 0;
}
