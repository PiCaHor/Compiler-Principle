#include <sysy/sylib.h>
// Add is prior than equal and not equal
int main () {
    int a;
    int b;
    int c;
    a = 1;
    b = 4;
    c = 28;
    int t;
    if (c + a != b) {
        t = c % -b;
        putint(t);
    }
    if (b - c == a) {
        t = c%b+b;
        putint(t);
    }
    return 0;
}
