#include <sysy/sylib.h>
// Use minus with sub in one expr
int main () {
    int a;
    int b;
    a = -2;
    b = 1;
    a = a - -b + -(a + b) % -(a - b);
    putint(a);
    return 0;
}
