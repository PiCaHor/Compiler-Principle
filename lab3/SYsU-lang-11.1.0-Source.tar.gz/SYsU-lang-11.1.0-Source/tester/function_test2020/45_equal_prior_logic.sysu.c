#include <sysy/sylib.h>
// Equal is prior to logic operator
int main () {
    int a;
    int b;
    int c;
    int d;
    a = 10;
    b = 6;
    c = 4;
    d = 5;
    int t;
    if (b + c == a && d != a / 2) {
        t = b + c / d * 2;
        putint(t);
    }
    if (c < 0 || a - c == b && a != d * 2) {
        t = 1;
        putint(t);
    }
    return 0;
}
