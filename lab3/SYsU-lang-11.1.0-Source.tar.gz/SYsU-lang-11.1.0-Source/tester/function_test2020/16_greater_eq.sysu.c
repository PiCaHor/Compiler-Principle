int a=5;
int s[10]={9,8,7,6,5,4,3,2,1};

int main(){
    int i=0;
    while(s[i]>=a){
        i=i+1;
    }
    return i;
}