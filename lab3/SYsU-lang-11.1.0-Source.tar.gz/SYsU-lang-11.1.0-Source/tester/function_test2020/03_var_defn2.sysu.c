int a,b;

int main(){
    a=10;
    b=5;
    int c=a*2+b+3;
    return c;
}