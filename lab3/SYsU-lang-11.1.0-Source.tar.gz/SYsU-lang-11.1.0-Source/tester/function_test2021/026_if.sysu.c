int a;

int main(){
	a = 10;
	if( a>0 ){
		return 1;
	}
	return 0;
}
