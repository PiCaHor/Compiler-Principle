int a[10];
int main(){
	return 0;
}
