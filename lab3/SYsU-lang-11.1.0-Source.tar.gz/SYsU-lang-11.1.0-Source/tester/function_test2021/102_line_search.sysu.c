#include <sysy/sylib.h>

int main()
{
    //newline=10;
    int i;
    int sum;
    int a[10];
    sum=0;
    //m = 1478;
    //int t;
    i=0;
    while(i<10)
    {
        a[i]=i+1;
        i=i+1;
    }
    int x;
    int high;
    int low;
    int mid;
    int n;
    n=10;
    x=getint();
    high=n-1;
    low=0;
    mid=(high+low)/2;
    int flag;
    flag=0;
    //int i;
    i=0;
    int j;
    j=0;
    while(i<10 && flag==0)
    {
        if(a[i]==x)
        {
            flag=1;
            j=i;
        }
        
        i=i+1;
       
    }

     if(flag==1)
        putint(j);
        else
        {
            x = 0;
            putint(x);
        }
        


    x= 10;
    putch(x);

    return 0;
}
