//test comment
int main(){
    int a, b;
    a = 10;
    b = 2;
    /*/*
        b = 1;
        // b = 2
    */
    return b;
}