int main(){
    /*
    The comment block;
    int a=5;
    int b[10];
    int c;
    int d=a*2;
    */
    return 0;
}