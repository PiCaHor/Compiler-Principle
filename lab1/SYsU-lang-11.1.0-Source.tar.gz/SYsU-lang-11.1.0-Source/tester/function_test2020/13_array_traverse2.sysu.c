int a[3][3][3];

int main(){
    int i,j,k;
    i=0;j=0;k=0;
    int cnt=0;
    while(i<3){
        while(j<3){
            while(k<3){
                a[i][j][k]=cnt;
                cnt=cnt+1;
                k=k+1;
            }
            j=j+1;
        }
        i=i+1;
    }
    return 0;
}