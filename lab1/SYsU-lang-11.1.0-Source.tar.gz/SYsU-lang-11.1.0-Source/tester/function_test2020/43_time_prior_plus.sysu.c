#include <sysy/sylib.h>
// Check the priority between time and plus
int main() {
    int a;
    a = 20;
    int b;
    b = 5;
    int c;
    c = 6;
    int d;
    d = -4;
    a = a + c * d - b % (a + d) / a;
    putint(a);
    return 0;
}
