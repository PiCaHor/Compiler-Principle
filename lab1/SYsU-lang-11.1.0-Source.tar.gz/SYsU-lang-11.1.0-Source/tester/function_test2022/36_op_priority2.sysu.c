//test the priority of add and mul
int main(){
    int a, b, c, d;
    a = 10;
    b = 4;
    c = 2;
    d = 2;
    return (c + a) * (b - d); 
}