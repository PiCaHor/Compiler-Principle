#include <sysy/sylib.h>
// ???  // ????
  				// ?????
/*

int main() {
  int arr[100], i = 0, sum = 0;
  while (getint()) {
  	arr[i] = getint();
    i = i + 1;
  }*/
int main() {
  int arr[100], i = 0, sum = 0;
  while (getint()) {
  	arr[i] = getint();
    i = i + 1;
  }
	while (i) {
    i = i - 1;
    sum = sum + arr[i];
  }
  return sum % 79;
}