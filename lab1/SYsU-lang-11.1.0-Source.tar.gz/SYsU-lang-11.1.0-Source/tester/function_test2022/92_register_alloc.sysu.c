#include <sysy/sylib.h>
int a1 = 1;
int a2 = 2;
int a3 = 3;
int a4 = 4;
int a5 = 5;
int a6 = 6;
int a7 = 7;
int a8 = 8;
int a9 = 9;
int a10 = 10;
int a11 = 11;
int a12 = 12;
int a13 = 13;
int a14 = 14;
int a15 = 15;
int a16 = 16;
int a17 = 1;
int a18 = 2;
int a19 = 3;
int a20 = 4;
int a21 = 5;
int a22 = 6;
int a23 = 7;
int a24 = 8;
int a25 = 9;
int a26 = 10;
int a27 = 11;
int a28 = 12;
int a29 = 13;
int a30 = 14;
int a31 = 15;
int a32 = 16;

int func(int a, int b){
    int i;
    i = a + b;

    int c1;int c2;int c3;int c4;
    int d1;int d2;int d3;int d4;
    int e1;int e2;int e3;int e4;
    int f1;int f2;int f3;int f4;
    int g1;int g2;int g3;int g4;
    int h1;int h2;int h3;int h4;
    int i1;int i2;int i3;int i4;
    int j1;int j2;int j3;int j4;
    int k1;int k2;int k3;int k4;    
    c1 = getint();c2 = getint();c3 = getint();c4 = getint();
    d1 = 1 + c1 + a1;d2 = 2 + c2 + a2;d3 = 3 + c3 + a3;d4 = 4 + c4 + a4;
    e1 = 1 + d1 + a5;e2 = 2 + d2 + a6;e3 = 3 + d3 + a7;e4 = 4 + d4 + a8;
    f1 = 1 + e1 + a9;f2 = 2 + e2 + a10;f3 = 3 + e3 + a11;f4 = 4 + e4 + a12;
    g1 = 1 + f1 + a13;g2 = 2 + f2 + a14;g3 = 3 + f3 + a15;g4 = 4 + f4 + a16;
    h1 = 1 + g1 + a17;h2 = 2 + g2 + a18;h3 = 3 + g3 + a19;h4 = 4 + g4 + a20;
    i1 = 1 + h1 + a21;i2 = 2 + h2 + a22;i3 = 3 + h3 + a23;i4 = 4 + h4 + a24;
    j1 = 1 + i1 + a25;j2 = 2 + i2 + a26;j3 = 3 + i3 + a27;j4 = 4 + i4 + a28;
    k1 = 1 + j1 + a29;k2 = 2 + j2 + a30;k3 = 3 + j3 + a31;k4 = 4 + j4 + a32;

    i = a - b + 10;
    k1 = 1 + j1 + a29;k2 = 2 + j2 + a30;k3 = 3 + j3 + a31;k4 = 4 + j4 + a32;
    j1 = 1 + i1 + a25;j2 = 2 + i2 + a26;j3 = 3 + i3 + a27;j4 = 4 + i4 + a28;
    i1 = 1 + h1 + a21;i2 = 2 + h2 + a22;i3 = 3 + h3 + a23;i4 = 4 + h4 + a24;
    h1 = 1 + g1 + a17;h2 = 2 + g2 + a18;h3 = 3 + g3 + a19;h4 = 4 + g4 + a20;
    g1 = 1 + f1 + a13;g2 = 2 + f2 + a14;g3 = 3 + f3 + a15;g4 = 4 + f4 + a16;
    f1 = 1 + e1 + a9;f2 = 2 + e2 + a10;f3 = 3 + e3 + a11;f4 = 4 + e4 + a12;
    e1 = 1 + d1 + a5;e2 = 2 + d2 + a6;e3 = 3 + d3 + a7;e4 = 4 + d4 + a8;
    d1 = 1 + c1 + a1;d2 = 2 + c2 + a2;d3 = 3 + c3 + a3;d4 = 4 + c4 + a4;
    d1 = 1 + c1 + a1;d2 = 2 + c2 + a2;d3 = 3 + c3 + a3;d4 = 4 + c4 + a4;
    return i + c1 + c2 + c3 + c4 
        - d1 - d2 - d3 - d4 
        + e1 + e2 + e3 + e4 
        - f1 - f2 - f3 - f4 
        + g1 + g2 + g3 + g4 
        - h1 - h2 - h3 - h4 
        + i1 + i2 + i3 + i4 
        - j1 - j2 - j3 - j4 
        + k1 + k2 + k3 + k4
        + a1 - a2 + a3 - a4
        + a5 - a6 + a7 - a8
        + a9 - a10 + a11 - a12
        + a13 - a14 + a15 - a16
        + a17 - a18 + a19 - a20
        + a21 - a22 + a23 - a24
        + a25 - a26 + a27 - a28
        + a29 - a30 + a31 - a32;
}

int main(){
    int a;
    int b;
    a = getint();
    b = a + 2 * 9;
    a = func(a, b);
    putint(a);
    return a;
}