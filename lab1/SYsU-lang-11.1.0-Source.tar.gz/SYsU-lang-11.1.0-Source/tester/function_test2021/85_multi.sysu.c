#include <sysy/sylib.h>
int main()
{
    //newline=10;
    int i;
    int sum;
    sum=0;
    //m = 1478;
    //int t;
    i=0;
    while(i<21)
    {
        sum=sum*i;
        i=i+1;
    }
    
    putint(sum);

    return 0;
}
