//test global var define
int a = 3;
int b = 5;

int main(){
    return a + b;
}